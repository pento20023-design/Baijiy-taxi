import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://xvrfcqhnzrkjzmqvxanl.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh2cmZjcWhuenJranptcXZ4YW5sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE1MzIzMzIsImV4cCI6MjEwNzEwODMzMn0.iiuuAVfo4jtCFxAIRrO6W9HhGUJjskSIbCAG_Cjpasw';
const privacyUrl = 'https://pento20026-ops.github.io/privacy.html';
const mapTiles = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const endStatuses = ['مكتملة', 'مرفوضة', 'ملغاة', 'لم يحضر'];

SupabaseClient get sb => Supabase.instance.client;

enum AppKind { customer, driver, admin }

/// ===== ألوان الهوية البصرية =====
class C {
  static const yel = Color(0xFFFFC72C);
  static const navy = Color(0xFF0B1F4B);
  static const night = Color(0xFF0B1120);
  static const card = Color(0xFF131C31);
  static const green = Color(0xFF00E676);
}

/// لوحة ألوان تتبدّل بين النهاري والليلي
class Pal {
  final bool dark;
  const Pal(this.dark);
  static Pal of(BuildContext c) => Pal(Theme.of(c).brightness == Brightness.dark);
  Color get bg => dark ? C.night : const Color(0xFFF3F5FA);
  Color get card => dark ? C.card : Colors.white;
  Color get card2 => dark ? const Color(0xFF1A2540) : const Color(0xFFF8FAFC);
  Color get field => dark ? const Color(0xFF0E1730) : Colors.white;
  Color get line => dark ? const Color(0xFF26324F) : const Color(0xFFE2E8F0);
  Color get text => dark ? const Color(0xFFF1F5F9) : const Color(0xFF0B1F4B);
  Color get sub => dark ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
  Color get soft => dark ? const Color(0xFF1D2744) : const Color(0xFFFFF8E1);
  Color get accent => dark ? C.yel : C.navy;
  Color get link => dark ? const Color(0xFF7DB4FF) : const Color(0xFF1D4ED8);
  Color get ok => dark ? C.green : const Color(0xFF15803D);
  Color get head => dark ? const Color(0xFF0F1830) : C.navy;
}


/// ===== تخزين محلي بملف (بديل عن مكتبة التفضيلات التي تتعطل على بعض الأجهزة) =====
class Store {
  static Map<String, String>? _m;
  static File? _f;
  static Future<void> _init() async {
    if (_m != null) return;
    try {
      final d = await getApplicationSupportDirectory();
      _f = File('${d.path}/baiji_store.json');
      if (await _f!.exists()) {
        final j = jsonDecode(await _f!.readAsString()) as Map;
        _m = j.map((k, v) => MapEntry('$k', '$v'));
      }
    } catch (_) {}
    _m ??= {};
  }

  static Future<String?> get(String k) async { await _init(); return _m![k]; }
  static Future<void> set(String k, String v) async {
    await _init();
    _m![k] = v;
    try { await _f?.writeAsString(jsonEncode(_m)); } catch (_) {}
  }
  static Future<void> remove(String k) async {
    await _init();
    _m!.remove(k);
    try { await _f?.writeAsString(jsonEncode(_m)); } catch (_) {}
  }
}

/// حفظ جلسة الدخول في ملف حتى لا يُسجَّل الخروج عند إغلاق التطبيق
class FileLocalStorage extends LocalStorage {
  @override
  Future<void> initialize() async {}

  @override
  Future<bool> hasAccessToken() async => (await Store.get('sb_session')) != null;

  @override
  Future<String?> accessToken() async => Store.get('sb_session');

  @override
  Future<void> removePersistedSession() async => Store.remove('sb_session');

  @override
  Future<void> persistSession(String persistSessionString) async => Store.set('sb_session', persistSessionString);
}

class FileAsyncStorage extends GotrueAsyncStorage {
  @override
  Future<String?> getItem({required String key}) => Store.get('g_$key');
  @override
  Future<void> setItem({required String key, required String value}) => Store.set('g_$key', value);
  @override
  Future<void> removeItem({required String key}) => Store.remove('g_$key');
}

final themeMode = ValueNotifier<ThemeMode>(ThemeMode.dark);

Future<void> loadTheme() async {
  try {
    final s = await Store.get('theme');
    if (s == 'light') themeMode.value = ThemeMode.light;
  } catch (_) {}
}

Future<void> setDark(bool d) async {
  themeMode.value = d ? ThemeMode.dark : ThemeMode.light;
  await Store.set('theme', d ? 'dark' : 'light');
}

ThemeData buildTheme(Brightness b) {
  final p = Pal(b == Brightness.dark);
  final base = ThemeData(
    brightness: b,
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: C.yel, brightness: b, primary: p.accent, secondary: C.yel, surface: p.card),
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.card,
  );
  return base.copyWith(
    textTheme: GoogleFonts.tajawalTextTheme(base.textTheme).apply(bodyColor: p.text, displayColor: p.text),
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? C.yel : null),
      checkColor: WidgetStateProperty.all(C.navy),
      side: BorderSide(color: p.sub, width: 1.5),
    ),
  );
}

final messengerKey = GlobalKey<ScaffoldMessengerState>();

void toast(String t) {
  messengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: Colors.white)),
      backgroundColor: const Color(0xFF16213C),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(milliseconds: 3500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: C.yel)),
    ));
}

void click() => SystemSound.play(SystemSoundType.click);

Future<void> openUrl(String u) async {
  try {
    await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {
    toast('تعذر فتح الرابط');
  }
}

Future<bool> confirmDlg(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم')),
      ],
    ),
  );
  return r == true;
}

/// ===== الشعارات =====
class AppLogo extends StatelessWidget {
  final AppKind kind;
  final double size;
  const AppLogo(this.kind, {super.key, this.size = 56});
  @override
  Widget build(BuildContext context) {
    final isCust = kind == AppKind.customer;
    final bg = isCust ? C.navy : C.yel;
    final fg = isCust ? C.yel : C.navy;
    final label = kind == AppKind.admin ? 'Taxe' : 'TAXI';
    return Container(
      width: size, height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(size * .24),
        border: Border.all(color: C.yel, width: max(2, size * .045)),
        boxShadow: const [BoxShadow(color: Color(0x40FFC72C), blurRadius: 18)],
      ),
      child: Text(label, textDirection: TextDirection.ltr, style: TextStyle(color: fg, fontWeight: FontWeight.w900, fontSize: size * .3, letterSpacing: 1)),
    );
  }
}

/// ظهور متحرك للعناصر
class FadeIn extends StatelessWidget {
  final Widget child;
  final int ms;
  final double dy;
  const FadeIn({super.key, required this.child, this.ms = 600, this.dy = 18});
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: ms),
        curve: Curves.easeOutCubic,
        builder: (_, v, ch) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, (1 - v) * dy), child: ch)),
        child: child,
      );
}

/// ===== الأزرار =====
enum BK { yellow, navy, white, red, green, sky, gray }

class AppBtn extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final BK kind;
  final IconData? icon;
  final double vPad;
  const AppBtn(this.text, this.onTap, {super.key, this.kind = BK.navy, this.icon, this.vPad = 13});

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    late List<Color> g;
    late Color fg;
    Border? border;
    switch (kind) {
      case BK.yellow:
        g = [const Color(0xFFFFD75E), C.yel]; fg = C.navy; break;
      case BK.navy:
        g = p.dark ? [const Color(0xFF1B2748), const Color(0xFF16213C)] : [const Color(0xFF14327A), C.navy];
        fg = C.yel; border = Border.all(color: const Color(0x73FFC72C)); break;
      case BK.white:
        g = [p.card, p.card]; fg = p.text; border = Border.all(color: p.line); break;
      case BK.red:
        g = [const Color(0xFFEF4444), const Color(0xFFDC2626)]; fg = Colors.white; break;
      case BK.green:
        g = [C.green, const Color(0xFF00C46A)]; fg = const Color(0xFF04210F); break;
      case BK.sky:
        g = [const Color(0xFF38BDF8), const Color(0xFF0284C7)]; fg = Colors.white; break;
      case BK.gray:
        g = p.dark ? [const Color(0xFF2A3554), const Color(0xFF2A3554)] : [const Color(0xFFE2E8F0), const Color(0xFFE2E8F0)];
        fg = p.dark ? const Color(0xFFCBD5E1) : const Color(0xFF334155); break;
    }
    final on = onTap != null;
    return Opacity(
      opacity: on ? 1 : .55,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: on ? () { click(); onTap!(); } : null,
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: g, begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(14),
              border: border,
            ),
            padding: EdgeInsets.symmetric(vertical: vPad, horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[Icon(icon, size: 17, color: fg), const SizedBox(width: 6)],
                Flexible(child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: fg, fontWeight: FontWeight.w900, fontSize: 14))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

InputDecoration inDec(BuildContext c, String hint, {IconData? icon}) {
  final p = Pal.of(c);
  OutlineInputBorder b(Color col, [double w = 1]) => OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: col, width: w));
  return InputDecoration(
    hintText: hint,
    hintStyle: TextStyle(color: p.sub, fontSize: 13),
    prefixIcon: icon == null ? null : Icon(icon, size: 19, color: p.sub),
    filled: true,
    fillColor: p.field,
    isDense: true,
    contentPadding: const EdgeInsets.all(13),
    border: b(p.line),
    enabledBorder: b(p.line),
    focusedBorder: b(p.dark ? C.yel : C.navy, 2),
  );
}

Widget appHeader(BuildContext c, AppKind kind, String title, String sub, {List<Widget> actions = const []}) {
  final p = Pal.of(c);
  return Container(
    decoration: BoxDecoration(color: p.head, border: const Border(bottom: BorderSide(color: C.yel, width: 3))),
    child: SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(children: [
          AppLogo(kind, size: 46),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900, fontSize: 18, height: 1.1)),
              Text(sub, style: const TextStyle(color: Color(0xFFCBD5E1), fontSize: 10)),
            ]),
          ),
          ...actions,
        ]),
      ),
    ),
  );
}

/// ===== الإشعارات =====
class Notifier {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const _ch = AndroidNotificationChannel('rides', 'طلبات الرحلات',
      description: 'تنبيهات الطلبات وحالة الرحلة', importance: Importance.max);

  static Future<void> init() async {
    try {
      await _p.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
      await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(_ch);
      _ready = true;
    } catch (_) {}
  }

  static Future<bool> ask() async {
    try {
      final r = await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
      return r ?? true;
    } catch (_) { return false; }
  }

  static Future<void> show(String t, String b) async {
    if (!_ready) return;
    try {
      HapticFeedback.vibrate();
      await _p.show(
        DateTime.now().millisecondsSinceEpoch % 2147483000, t, b,
        NotificationDetails(android: AndroidNotificationDetails(_ch.id, _ch.name,
            channelDescription: _ch.description, importance: Importance.max, priority: Priority.high)),
      );
    } catch (_) {}
  }
}

/// ===== الموقع =====
Future<bool> locOk() async {
  return (await Store.get('locOK')) == '1';
}
Future<void> setLocOk() async {
  await Store.set('locOK', '1');
}

String locMsg(Object e) {
  final m = e.toString().toLowerCase();
  if (RegExp('denied|permission').hasMatch(m)) return 'إذن الموقع مرفوض: فعّله للتطبيق من إعدادات الهاتف';
  if (RegExp('disabled|services|enabled|unavailable').hasMatch(m)) return 'خدمة الموقع (GPS) مغلقة: شغّلها من الإعدادات السريعة ثم أعد المحاولة';
  return 'تعذر تحديد الموقع، تأكد من تشغيل GPS وإذن الموقع';
}

Future<bool> ensureLocPermission() async {
  if (!await Geolocator.isLocationServiceEnabled()) throw 'disabled';
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) throw 'permission denied';
  return true;
}

Future<Position> getPos() async {
  await ensureLocPermission();
  return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
}

Future<void> showLocDisclosure(BuildContext c, String body, VoidCallback onYes) {
  return showDialog(
    context: c,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: C.yel, width: 2)),
      title: const Column(children: [Icon(Icons.my_location, size: 40, color: C.yel), SizedBox(height: 8), Text('استخدام الموقع', style: TextStyle(fontWeight: FontWeight.w900))]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(body, style: const TextStyle(fontSize: 13, height: 1.6)),
        const SizedBox(height: 8),
        GestureDetector(onTap: () => openUrl(privacyUrl), child: const Text('سياسة الخصوصية', style: TextStyle(decoration: TextDecoration.underline, fontSize: 11))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('ليس الآن')),
        TextButton(onPressed: () async { await setLocOk(); if (c.mounted) Navigator.pop(c); onYes(); }, child: const Text('موافق', style: TextStyle(fontWeight: FontWeight.w900))),
      ],
    ),
  );
}

String arErr(Object? m) {
  final s = (m is AuthException ? m.message : m).toString();
  if (RegExp('Invalid login', caseSensitive: false).hasMatch(s)) return 'البريد الإلكتروني أو كلمة السر غير صحيحة';
  if (RegExp('not confirmed', caseSensitive: false).hasMatch(s)) return 'يرجى تأكيد بريدك من الرسالة المرسلة إليك أولاً';
  if (RegExp('already registered|already been registered', caseSensitive: false).hasMatch(s)) return 'هذا البريد مسجّل مسبقاً، سجّل الدخول';
  if (RegExp('at least 6|weak', caseSensitive: false).hasMatch(s)) return 'كلمة السر ضعيفة (6 أحرف على الأقل)';
  if (RegExp('valid email|invalid format', caseSensitive: false).hasMatch(s)) return 'البريد الإلكتروني غير صالح';
  if (RegExp('rate limit|too many', caseSensitive: false).hasMatch(s)) return 'محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة';
  if (RegExp('fetch|network|socket', caseSensitive: false).hasMatch(s)) return 'لا يوجد اتصال بالإنترنت';
  return s;
}

/// ===== عناصر الخريطة =====
Widget meDot() => Container(
      width: 18, height: 18,
      decoration: BoxDecoration(color: const Color(0xFF1A73E8), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Color(0x801A73E8), blurRadius: 8)]),
    );

Widget carDot() => Container(
      width: 34, height: 34,
      decoration: BoxDecoration(color: C.yel, shape: BoxShape.circle, border: Border.all(color: C.navy, width: 2),
          boxShadow: const [BoxShadow(color: Color(0x80000000), blurRadius: 8)]),
      child: const Icon(Icons.local_taxi, size: 19, color: C.navy),
    );

Widget pinIcon(Color color, {String? label}) => Column(mainAxisSize: MainAxisSize.min, children: [
      if (label != null)
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99)),
          child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
        ),
      Icon(Icons.location_on, color: color, size: 44, shadows: const [Shadow(color: Color(0x59000000), blurRadius: 4, offset: Offset(0, 3))]),
    ]);

Widget roundMapBtn(BuildContext c, IconData i, VoidCallback f) {
  final p = Pal.of(c);
  return Material(
    color: p.card, shape: const CircleBorder(), elevation: 4,
    child: InkWell(customBorder: const CircleBorder(), onTap: () { click(); f(); }, child: SizedBox(width: 44, height: 44, child: Icon(i, color: p.accent, size: 19))),
  );
}

Widget mapChip(BuildContext c, String t) {
  final p = Pal.of(c);
  return Material(
    color: p.card, elevation: 4, borderRadius: BorderRadius.circular(99),
    child: Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12), child: Text(t, textAlign: TextAlign.center, style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 13))),
  );
}

Widget mapSheet(BuildContext c, Widget child) {
  final p = Pal.of(c);
  return Container(
    width: double.infinity,
    decoration: BoxDecoration(color: p.card, borderRadius: const BorderRadius.vertical(top: Radius.circular(24)), boxShadow: const [BoxShadow(color: Color(0x40000000), blurRadius: 24)]),
    padding: const EdgeInsets.all(16),
    child: SafeArea(top: false, child: child),
  );
}

double distKm(LatLng a, LatLng b) {
  double r(double x) => x * pi / 180;
  final h = pow(sin(r(b.latitude - a.latitude) / 2), 2) + cos(r(a.latitude)) * cos(r(b.latitude)) * pow(sin(r(b.longitude - a.longitude) / 2), 2);
  return (12742 * asin(sqrt(h)) * 1.25 * 10).round() / 10;
}

/// ===== المسار داخل التطبيق (مثل Waze) عبر خدمة OSRM المجانية =====
class RouteInfo {
  final List<LatLng> pts;
  final double km, min;
  RouteInfo(this.pts, this.km, this.min);
}

Future<RouteInfo?> osrmRoute(LatLng a, LatLng b) async {
  HttpClient? c;
  try {
    final u = Uri.parse('https://router.project-osrm.org/route/v1/driving/${a.longitude},${a.latitude};${b.longitude},${b.latitude}?overview=full&geometries=geojson');
    c = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    final req = await c.getUrl(u);
    final res = await req.close().timeout(const Duration(seconds: 12));
    final body = await res.transform(utf8.decoder).join();
    final j = jsonDecode(body);
    final r = j['routes'][0];
    final pts = (r['geometry']['coordinates'] as List).map((e) => LatLng((e[1] as num).toDouble(), (e[0] as num).toDouble())).toList();
    return RouteInfo(pts, (r['distance'] as num) / 1000, (r['duration'] as num) / 60);
  } catch (_) {
    return null;
  } finally {
    c?.close(force: true);
  }
}

/// موقع السائق المخزَّن في سجل الرحلة (يبحث عن أعمدة lat/lng غير أعمدة الانطلاق والوجهة)
LatLng? driverPosOf(Map<String, dynamic> r) {
  double? la, lo;
  r.forEach((k, v) {
    final key = '$k'.toLowerCase();
    if (key.startsWith('pickup') || key.startsWith('drop') || v == null) return;
    if (key.contains('lat')) la = double.tryParse('$v') ?? la;
    if (key.contains('lng') || key.contains('lon')) lo = double.tryParse('$v') ?? lo;
  });
  return (la != null && lo != null) ? LatLng(la!, lo!) : null;
}

String fmtMoney(num v) {
  final s = v.round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return '$b د.ع';
}

/// ===== شاشة البدء المتحركة + تهيئة آمنة =====
class Boot extends StatefulWidget {
  final AppKind kind;
  final Widget child;
  const Boot({super.key, required this.kind, required this.child});
  @override
  State<Boot> createState() => _BootState();
}

class _BootState extends State<Boot> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 2800))..forward();
  bool ready = false, minDone = false;
  Object? err;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2800), () { if (mounted) setState(() => minDone = true); });
    start();
  }

  @override
  void dispose() { ac.dispose(); super.dispose(); }

  Future<void> start() async {
    setState(() { err = null; ready = false; });
    try {
      await loadTheme();
      await Supabase.initialize(
        url: supabaseUrl,
        anonKey: supabaseKey,
        authOptions: FlutterAuthClientOptions(localStorage: FileLocalStorage(), pkceAsyncStorage: FileAsyncStorage()),
      ).timeout(const Duration(seconds: 20));
      await Notifier.init().timeout(const Duration(seconds: 10), onTimeout: () {});
      if (mounted) setState(() => ready = true);
    } catch (e) {
      if (mounted) setState(() => err = e);
    }
  }

  String get title => widget.kind == AppKind.customer ? 'تكسي بيجي' : (widget.kind == AppKind.driver ? 'سائق تكسي بيجي' : 'إدارة تكسي بيجي');
  String get sub => widget.kind == AppKind.customer ? 'رحلات آمنة وسريعة' : (widget.kind == AppKind.driver ? 'مركز عمليات السائق' : 'لوحة التحكم');

  Widget splash() {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: C.night,
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(colors: [C.night, Color(0xFF111B36), C.night], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child: AnimatedBuilder(
            animation: ac,
            builder: (_, __) {
              final t = ac.value;
              final logoT = Curves.elasticOut.transform((t / .45).clamp(0.0, 1.0));
              final textT = Curves.easeOut.transform(((t - .35) / .35).clamp(0.0, 1.0));
              final carT = Curves.easeInOut.transform(((t - .15) / .85).clamp(0.0, 1.0));
              final pulse = (sin(t * pi * 5) + 1) / 2;
              final w = MediaQuery.of(context).size.width;
              return Stack(children: [
                Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Stack(alignment: Alignment.center, children: [
                      Container(
                        width: 150 + pulse * 22, height: 150 + pulse * 22,
                        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: C.yel.withOpacity(.12 + pulse * .12), width: 2)),
                      ),
                      Transform.scale(scale: logoT, child: AppLogo(widget.kind, size: 110)),
                    ]),
                    const SizedBox(height: 26),
                    Opacity(
                      opacity: textT,
                      child: Transform.translate(
                        offset: Offset(0, (1 - textT) * 16),
                        child: Column(children: [
                          Text(title, style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900, fontSize: 28)),
                          const SizedBox(height: 4),
                          Text(sub, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 13)),
                        ]),
                      ),
                    ),
                    if (err != null) ...[
                      const SizedBox(height: 28),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: SelectableText('تعذر تشغيل التطبيق\n$err', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                      ),
                      const SizedBox(height: 10),
                      ElevatedButton(onPressed: start, child: const Text('إعادة المحاولة')),
                    ],
                  ]),
                ),
                Positioned(
                  left: 0, right: 0, bottom: 70,
                  child: SizedBox(
                    height: 46,
                    child: Stack(children: [
                      Positioned(left: 40, right: 40, bottom: 8, child: Container(height: 3, decoration: BoxDecoration(color: const Color(0xFF26324F), borderRadius: BorderRadius.circular(3)))),
                      Positioned(
                        left: 40 + (w - 80 - 34) * carT, bottom: 4,
                        child: Transform.scale(scaleX: -1, child: const Icon(Icons.local_taxi, color: C.yel, size: 34)),
                      ),
                    ]),
                  ),
                ),
              ]);
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final show = ready && minDone;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 550),
      child: show ? KeyedSubtree(key: const ValueKey('app'), child: widget.child) : KeyedSubtree(key: const ValueKey('splash'), child: MaterialApp(debugShowCheckedModeBanner: false, home: splash())),
    );
  }
}
