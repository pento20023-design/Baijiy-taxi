import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core.dart';

const allStatuses = ['جديد', 'تم القبول', 'السائق في الطريق', 'بدأت الرحلة', 'مكتملة', 'مرفوضة', 'ملغاة', 'لم يحضر'];

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Boot(kind: AppKind.admin, child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (_, m, __) => MaterialApp(
          title: 'إدارة تكسي بيجي',
          debugShowCheckedModeBanner: false,
          scaffoldMessengerKey: messengerKey,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: m,
          home: const AdminGate(),
        ),
      );
}

Color statusColor(String s) {
  switch (s) {
    case 'جديد': return const Color(0xFF3B82F6);
    case 'تم القبول': return const Color(0xFF6366F1);
    case 'السائق في الطريق':
    case 'بدأت الرحلة': return const Color(0xFFF59E0B);
    case 'مكتملة': return const Color(0xFF22C55E);
    case 'مرفوضة':
    case 'لم يحضر': return const Color(0xFFEF4444);
    default: return const Color(0xFF94A3B8);
  }
}

Widget badge(String s) {
  final c = statusColor(s);
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(color: c.withOpacity(.16), borderRadius: BorderRadius.circular(99), border: Border.all(color: c.withOpacity(.5))),
    child: Text(s, style: TextStyle(color: c, fontWeight: FontWeight.w900, fontSize: 10)),
  );
}

String fmtD(dynamic x) {
  try {
    final d = DateTime.parse('$x').toLocal();
    String t(int n) => n.toString().padLeft(2, '0');
    return '${t(d.day)}/${t(d.month)} ${t(d.hour)}:${t(d.minute)}';
  } catch (_) { return ''; }
}

/// بداية الأسبوع (السبت)
DateTime weekStart() {
  final n = DateTime.now();
  final d = (n.weekday + 1) % 7;
  return DateTime(n.year, n.month, n.day).subtract(Duration(days: d));
}

/// ============ البوابة ============
class AdminGate extends StatefulWidget {
  const AdminGate({super.key});
  @override
  State<AdminGate> createState() => _AdminGateState();
}

class _AdminGateState extends State<AdminGate> {
  User? user = sb.auth.currentUser;
  StreamSubscription<AuthState>? sub;
  final em = TextEditingController(), pw = TextEditingController();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    sub = sb.auth.onAuthStateChange.listen((s) {
      if (!mounted) return;
      if (s.event == AuthChangeEvent.signedOut) {
        setState(() => user = null);
      } else if (s.session != null) {
        setState(() => user = s.session!.user);
      }
    });
  }

  @override
  void dispose() { sub?.cancel(); super.dispose(); }

  Future<void> login() async {
    if (em.text.trim().isEmpty || pw.text.isEmpty) return toast('أدخل البريد وكلمة السر');
    setState(() => busy = true);
    try { await sb.auth.signInWithPassword(email: em.text.trim(), password: pw.text); }
    catch (e) { toast(arErr(e)); }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    if (user != null) return AdminHome(key: ValueKey(user!.id), user: user!);
    final p = Pal.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(gradient: LinearGradient(colors: p.dark ? [C.night, const Color(0xFF111B36)] : [C.navy, const Color(0xFF14327A)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child: SafeArea(
            child: Stack(children: [
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 380),
                    child: FadeIn(
                      child: Column(children: [
                        const AppLogo(AppKind.admin, size: 96),
                        const SizedBox(height: 14),
                        const Text('لوحة إدارة تكسي بيجي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: C.yel)),
                        const SizedBox(height: 22),
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.yel.withOpacity(.55), width: 1.5)),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            TextField(controller: em, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: inDec(context, 'البريد الإلكتروني', icon: Icons.mail_outline)),
                            const SizedBox(height: 11),
                            TextField(controller: pw, obscureText: true, textDirection: TextDirection.ltr, decoration: inDec(context, 'كلمة المرور', icon: Icons.lock_outline)),
                            const SizedBox(height: 14),
                            AppBtn('دخول الأدمن', busy ? null : login, kind: BK.yellow, icon: Icons.login, vPad: 14),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
              Positioned(top: 4, left: 4, child: IconButton(onPressed: () => setDark(!p.dark), icon: Icon(p.dark ? Icons.light_mode : Icons.dark_mode, color: C.yel))),
            ]),
          ),
        ),
      ),
    );
  }
}

/// إحصاءات سائق
class DrvStat {
  final Map<String, dynamic> d;
  int t = 0, done = 0, rej = 0, can = 0, act = 0, rev = 0, weekRev = 0, weekDone = 0;
  final List<Map<String, dynamic>> okL = [], badL = [];
  DrvStat(this.d);
}

/// ============ الشاشة الرئيسية للأدمن ============
class AdminHome extends StatefulWidget {
  final User user;
  const AdminHome({super.key, required this.user});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int tab = 0;
  bool? isAdmin;
  List<Map<String, dynamic>> rides = [], types = [], customers = [], drivers = [];
  Map<String, String> tn = {};
  Map<String, String> seen = {};
  RealtimeChannel? ch;
  Timer? statT, pollT;
  final alerted = <dynamic>{};
  bool firstRides = true;

  // الإحصاءات
  int period = 0;
  Map<String, DrvStat> by = {};
  Map<String, num> sum = {'t': 0, 'done': 0, 'rej': 0, 'can': 0, 'act': 0, 'rev': 0};
  int noDrv = 0, weekTotal = 0;
  final search = TextEditingController();
  String sort = 'done';
  int dl = 30;
  bool statsLoading = false;

  // حذف السجل
  String pgKind = 'done';
  int pgDays = 30;

  @override
  void initState() {
    super.initState();
    boot();
  }

  @override
  void dispose() {
    statT?.cancel();
    pollT?.cancel();
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> boot() async {
    try {
      final data = await sb.from('admins').select('user_id').eq('user_id', widget.user.id).maybeSingle();
      if (data == null) {
        toast('ليس أدمن. معرّفك: ${widget.user.id}');
        await sb.auth.signOut();
        return;
      }
    } catch (e) { toast('خطأ بالقاعدة: ${e is PostgrestException ? e.message : e}'); return; }
    if (!mounted) return;
    setState(() => isAdmin = true);
    Notifier.ask();
    await loadTypes();
    loadRides(); loadCust(); loadDrivers(); loadStats();
    pollT = Timer.periodic(const Duration(seconds: 8), (_) => loadRides(stats: false));
    ch = sb.channel('ar')
        .onPostgresChanges(event: PostgresChangeEvent.insert, schema: 'public', table: 'rides', callback: (p) {
          alertNewRide(p.newRecord);
          loadRides();
        })
        .onPostgresChanges(event: PostgresChangeEvent.update, schema: 'public', table: 'rides', callback: (p) {
          final n = p.newRecord;
          if (seen['${n['id']}'] == n['status']) return;
          seen['${n['id']}'] = '${n['status']}';
          final m = {
            'السائق في الطريق': '🚕 ${n['driver_name']} استلم طلب ${n['customer_name']}',
            'بدأت الرحلة': '▶️ بدأت رحلة ${n['customer_name']}',
            'مكتملة': '✅ اكتملت رحلة ${n['customer_name']}',
            'ملغاة': '❌ ألغى ${n['customer_name']} طلبه',
          };
          if (m[n['status']] != null) toast(m[n['status']]!);
          loadRides();
        })
        .onPostgresChanges(event: PostgresChangeEvent.all, schema: 'public', table: 'drivers', callback: (_) => loadDrivers())
        .subscribe();
  }

  void alertNewRide(Map<String, dynamic> n) {
    if (!alerted.add(n['id'])) return;
    SystemSound.play(SystemSoundType.alert);
    toast('🔔 طلب تكسي جديد من ${n['customer_name']}');
    Notifier.show('🔔 طلب تكسي جديد', '${n['customer_name']} · ${fmtMoney(num.tryParse('${n['fare']}') ?? 0)}');
  }

  String perr(Object e) => e is PostgrestException ? e.message : '$e';

  Future<void> loadTypes() async {
    try {
      final data = await sb.from('ride_types').select().order('sort');
      types = List<Map<String, dynamic>>.from(data);
      tn = {for (final t in types) '${t['key']}': '${t['name']}'};
      if (mounted) setState(() {});
    } catch (e) { toast(perr(e)); }
  }

  Future<void> loadRides({bool stats = true}) async {
    try {
      final data = await sb.from('rides').select().order('created_at', ascending: false).limit(50);
      rides = List<Map<String, dynamic>>.from(data);
      if (firstRides) {
        firstRides = false;
        alerted.addAll(rides.map((e) => e['id']));
      } else {
        for (final o in rides) { if (o['status'] == 'جديد') alertNewRide(o); }
      }
      for (final o in rides) { seen['${o['id']}'] = '${o['status']}'; }
      if (mounted) setState(() {});
      if (stats) {
        statT?.cancel();
        statT = Timer(const Duration(milliseconds: 1500), loadStats);
      }
    } catch (e) { if (stats) toast(perr(e)); }
  }

  Future<void> loadCust() async {
    try {
      final data = await sb.from('customers').select().order('strikes', ascending: false);
      customers = List<Map<String, dynamic>>.from(data);
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> loadDrivers() async {
    try {
      final data = await sb.from('drivers').select().order('verified').order('created_at', ascending: false);
      drivers = List<Map<String, dynamic>>.from(data);
      if (mounted) setState(() {});
      statT?.cancel();
      statT = Timer(const Duration(milliseconds: 800), loadStats);
    } catch (e) { toast(perr(e)); }
  }

  // ---------- إجراءات الرحلات ----------
  Future<void> setStatus(dynamic id, String s) async {
    try { await sb.from('rides').update({'status': s}).eq('id', id); } catch (e) { toast('❌ ${perr(e)}'); }
    loadRides();
  }

  Future<void> saveRideDriver(dynamic id, String n, String ph) async {
    try {
      await sb.from('rides').update({'driver_name': n.trim().isEmpty ? null : n.trim(), 'driver_phone': ph.trim().isEmpty ? null : ph.trim()}).eq('id', id);
      toast('✅ تم حفظ السائق');
    } catch (e) { toast('❌ ${perr(e)}'); }
    loadRides();
  }

  Future<void> noShow(dynamic id) async {
    if (!await confirmDlg(context, 'تأكيد أن الزبون لم يحضر؟ ستُسجَّل عليه مخالفة')) return;
    try { await sb.rpc('admin_ride_no_show', params: {'rid': id}); toast('تم تسجيل المخالفة'); } catch (e) { toast('❌ ${perr(e)}'); }
    loadRides(); loadCust();
  }

  Future<void> delRide(dynamic id) async {
    if (!await confirmDlg(context, 'حذف سجل هذه الرحلة نهائياً؟ لا يمكن التراجع.')) return;
    try {
      final d = await sb.from('rides').delete().eq('id', id).inFilter('status', endStatuses).select('id');
      toast(d.isEmpty ? '❌ لم يُحذف: صلاحية الحذف غير مفعّلة في Supabase' : 'تم حذف السجل');
    } catch (e) { toast('❌ ${perr(e)}'); }
    loadRides();
  }

  // ---------- السائقون والزبائن والأسعار ----------
  Future<void> dupd(String uid, Map<String, dynamic> v) async {
    try { await sb.from('drivers').update(v).eq('user_id', uid); toast('✅ تم'); } catch (e) { toast('❌ ${perr(e)}'); }
    loadDrivers();
  }

  Future<void> ddel(String uid) async {
    if (!await confirmDlg(context, 'حذف السائق؟')) return;
    try { await sb.from('drivers').delete().eq('user_id', uid); toast('تم الحذف'); } catch (e) { toast('❌ ${perr(e)}'); }
    loadDrivers();
  }

  Future<void> blk(String uid, bool b) async {
    final v = <String, dynamic>{'blocked': b};
    if (!b) v['strikes'] = 0;
    try { await sb.from('customers').update(v).eq('user_id', uid); toast('تم'); } catch (e) { toast('❌ ${perr(e)}'); }
    loadCust();
  }

  Future<void> price(String key, Map<String, dynamic> v) async {
    try { await sb.from('ride_types').update(v).eq('key', key); toast('✅ تم الحفظ'); } catch (e) { toast('❌ ${perr(e)}'); }
  }

  // ---------- الإحصاءات ----------
  Future<List<Map<String, dynamic>>> fetchRides(DateTime? since) async {
    var all = <Map<String, dynamic>>[];
    var from = 0;
    const step = 1000;
    for (var i = 0; i < 30; i++) {
      var q = sb.from('rides').select();
      if (since != null) q = q.gte('created_at', since.toUtc().toIso8601String());
      final data = await q.order('created_at', ascending: false).range(from, from + step - 1);
      all = all + List<Map<String, dynamic>>.from(data);
      if (data.length < step) break;
      from += step;
    }
    return all;
  }

  Future<void> loadStats() async {
    if (statsLoading) return;
    statsLoading = true;
    try {
      DateTime? since;
      final now = DateTime.now();
      if (period == 1) { since = DateTime(now.year, now.month, now.day); }
      else if (period > 1) { since = now.subtract(Duration(days: period)); }
      final ws = weekStart();
      final fetchSince = since == null ? null : (since.isBefore(ws) ? since : ws);
      final all = await fetchRides(fetchSince);
      final dr = await sb.from('drivers').select('user_id,name,phone,online,verified');
      final m = <String, DrvStat>{};
      final byPhone = <String, String>{};
      for (final d in List<Map<String, dynamic>>.from(dr)) {
        m['${d['user_id']}'] = DrvStat(d);
        if (d['phone'] != null) byPhone['${d['phone']}'] = '${d['user_id']}';
      }
      final s = <String, num>{'t': 0, 'done': 0, 'rej': 0, 'can': 0, 'act': 0, 'rev': 0};
      var none = 0, wt = 0;
      for (final r in all) {
        final created = DateTime.tryParse('${r['created_at']}')?.toLocal();
        final inPeriod = since == null || (created != null && !created.isBefore(since));
        final st = '${r['status']}';
        final fare = (num.tryParse('${r['fare']}') ?? 0).round();
        final isDone = st == 'مكتملة', isRej = st == 'مرفوضة', isCan = st == 'ملغاة' || st == 'لم يحضر';
        final isAct = !endStatuses.contains(st) && st != 'جديد';
        final k = m.containsKey('${r['driver_id']}') ? '${r['driver_id']}' : byPhone['${r['driver_phone']}'];
        // إيراد الأسبوع
        if (isDone && created != null && !created.isBefore(ws)) {
          wt += fare;
          if (k != null) { m[k]!.weekRev += fare; m[k]!.weekDone++; }
        }
        if (!inPeriod) continue;
        s['t'] = s['t']! + 1;
        if (isDone) { s['done'] = s['done']! + 1; s['rev'] = s['rev']! + fare; }
        else if (isRej) { s['rej'] = s['rej']! + 1; }
        else if (isCan) { s['can'] = s['can']! + 1; }
        else if (isAct) { s['act'] = s['act']! + 1; }
        if (k == null) { none++; continue; }
        final x = m[k]!;
        x.t++;
        if (isDone) { x.done++; x.rev += fare; x.okL.add(r); }
        else if (isRej) { x.rej++; x.badL.add(r); }
        else if (isCan) { x.can++; x.badL.add(r); }
        else if (isAct) { x.act++; x.okL.add(r); }
      }
      by = m; sum = s; noDrv = none; weekTotal = wt;
      if (mounted) setState(() {});
    } catch (e) { toast('❌ الإحصائيات: ${perr(e)}'); }
    statsLoading = false;
  }

  Future<void> purge() async {
    final statuses = pgKind == 'done' ? ['مكتملة'] : endStatuses;
    try {
      var q = sb.from('rides').select('id').inFilter('status', statuses);
      if (pgDays > 0) q = q.lt('created_at', DateTime.now().subtract(Duration(days: pgDays)).toUtc().toIso8601String());
      final rows = await q.limit(5000);
      final ids = rows.map((e) => e['id']).toList();
      if (ids.isEmpty) return toast('لا توجد سجلات مطابقة');
      if (!mounted) return;
      if (!await confirmDlg(context, 'سيتم حذف ${ids.length} رحلة نهائياً مع إحصائياتها، ولا يمكن التراجع. هل أنت متأكد؟')) return;
      if (pgDays == 0 && mounted && !await confirmDlg(context, 'تأكيد أخير: حذف كل السجلات المحددة بدون قيد التاريخ؟')) return;
      final d = await sb.from('rides').delete().inFilter('id', ids).select('id');
      if (d.isEmpty) return toast('❌ لم يُحذف شيء: صلاحية الحذف غير مفعّلة في Supabase');
      toast('✅ تم حذف ${d.length} سجل');
      loadRides();
    } catch (e) { toast('❌ ${perr(e)}'); }
  }

  // ---------- واجهة: الرحلات ----------
  Widget secTitle(String t, IconData i) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(children: [Icon(i, color: C.yel, size: 20), const SizedBox(width: 8), Text(t, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))]),
      );

  Widget ridesTab(Pal p) => ListView(padding: const EdgeInsets.all(14), children: [
        secTitle('الرحلات', Icons.notifications_active),
        if (rides.isEmpty) Padding(padding: const EdgeInsets.all(30), child: Center(child: Text('لا توجد رحلات', style: TextStyle(color: p.sub)))),
        for (final o in rides) RideCard(key: ValueKey('r${o['id']}-${o['status']}-${o['driver_name']}'), o: o, tn: tn, onStatus: setStatus, onSaveDriver: saveRideDriver, onNoShow: noShow, onDelete: delRide),
      ]);

  // ---------- واجهة: السائقون ----------
  Widget driversTab(Pal p) {
    final q = search.text.trim().toLowerCase();
    var arr = by.values.where((x) => q.isEmpty || '${x.d['name']}'.toLowerCase().contains(q) || '${x.d['phone']}'.contains(q)).toList();
    int key(DrvStat x) => sort == 't' ? x.t : (sort == 'rev' ? x.rev : (sort == 'week' ? x.weekRev : x.done));
    arr.sort((a, b) => key(b) != key(a) ? key(b).compareTo(key(a)) : b.done.compareTo(a.done));
    final shown = arr.take(dl).toList();
    final driverRows = {for (final d in drivers) '${d['user_id']}': d};
    return ListView(padding: const EdgeInsets.all(14), children: [
      secTitle('السائقون', Icons.badge),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: p.dark ? const Color(0xFF111B36) : C.navy, borderRadius: BorderRadius.circular(14), border: Border.all(color: C.yel, width: 1.5)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('إجمالي جمع الأسبوع', style: TextStyle(color: Color(0xFFCBD5E1), fontSize: 11, fontWeight: FontWeight.bold)), Text('كل السائقين', style: TextStyle(color: Color(0xFF94A3B8), fontSize: 10))]),
          Text(fmtMoney(weekTotal), style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900, fontSize: 22)),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(controller: search, onChanged: (_) => setState(() => dl = 30), decoration: inDec(context, 'ابحث باسم السائق أو رقمه', icon: Icons.search))),
        const SizedBox(width: 8),
        DropdownButton<String>(
          value: sort, underline: const SizedBox(),
          items: const [DropdownMenuItem(value: 'done', child: Text('الأكثر إنجازاً')), DropdownMenuItem(value: 't', child: Text('الأكثر طلبات')), DropdownMenuItem(value: 'rev', child: Text('الأعلى إيراداً')), DropdownMenuItem(value: 'week', child: Text('الأعلى هذا الأسبوع'))],
          onChanged: (v) => setState(() => sort = v ?? 'done'),
        ),
      ]),
      const SizedBox(height: 12),
      if (shown.isEmpty) Padding(padding: const EdgeInsets.all(30), child: Center(child: Text('لا يوجد سائقون مطابقون', style: TextStyle(color: p.sub)))),
      for (final x in shown)
        DriverCard(key: ValueKey('d${x.d['user_id']}'), x: x, row: driverRows['${x.d['user_id']}'], types: tn, onUpdate: dupd, onDelete: ddel),
      if (arr.length > dl) AppBtn('عرض المزيد من السائقين (${arr.length - dl})', () => setState(() => dl += 30), kind: BK.gray),
    ]);
  }

  // ---------- واجهة: الإحصاءات ----------
  Widget sumBox(Pal p, String v, String l, {Color? c}) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
          child: Column(children: [Text(v, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19, color: c ?? C.yel)), const SizedBox(height: 2), Text(l, textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: p.sub, fontWeight: FontWeight.bold))]),
        ),
      );

  Widget statsTab(Pal p) => ListView(padding: const EdgeInsets.all(14), children: [
        secTitle('الإحصائيات', Icons.bar_chart),
        Row(children: [
          const Text('الفترة:', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(width: 10),
          DropdownButton<int>(
            value: period, underline: const SizedBox(),
            items: const [DropdownMenuItem(value: 0, child: Text('كل الفترات')), DropdownMenuItem(value: 1, child: Text('اليوم')), DropdownMenuItem(value: 7, child: Text('آخر 7 أيام')), DropdownMenuItem(value: 30, child: Text('آخر 30 يوماً'))],
            onChanged: (v) { setState(() => period = v ?? 0); loadStats(); },
          ),
        ]),
        const SizedBox(height: 8),
        Row(children: [sumBox(p, '${sum['t']}', 'إجمالي الطلبات'), const SizedBox(width: 8), sumBox(p, '${sum['done']}', 'مكتملة', c: p.ok), const SizedBox(width: 8), sumBox(p, '${sum['rej']}', 'مرفوضة', c: const Color(0xFFEF4444))]),
        const SizedBox(height: 8),
        Row(children: [sumBox(p, '${sum['can']}', 'ملغاة / لم يحضر', c: const Color(0xFFF59E0B)), const SizedBox(width: 8), sumBox(p, fmtMoney(sum['rev'] ?? 0), 'الإيراد')]),
        if (noDrv > 0) Padding(padding: const EdgeInsets.only(top: 8), child: Text('طلبات بلا سائق محدد (جديدة أو مرفوضة من الإدارة): $noDrv', style: TextStyle(fontSize: 11, color: p.sub))),
        const SizedBox(height: 16),
        secTitle('ترتيب السائقين', Icons.emoji_events),
        Container(
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(flex: 3, child: Text('السائق', style: TextStyle(fontWeight: FontWeight.w900, color: p.sub, fontSize: 11))),
                Expanded(child: Text('مكتملة', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: p.sub, fontSize: 11))),
                Expanded(child: Text('الإنجاز', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: p.sub, fontSize: 11))),
                Expanded(flex: 2, child: Text('الإيراد', textAlign: TextAlign.end, style: TextStyle(fontWeight: FontWeight.w900, color: p.sub, fontSize: 11))),
              ]),
            ),
            for (final x in (by.values.toList()..sort((a, b) => b.rev.compareTo(a.rev))).take(20))
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(border: Border(top: BorderSide(color: p.line))),
                child: Row(children: [
                  Expanded(flex: 3, child: Text('${x.d['name']}', overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
                  Expanded(child: Text('${x.done}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900))),
                  Expanded(child: Text(x.done + x.rej + x.can == 0 ? '—' : '${(x.done * 100 / (x.done + x.rej + x.can)).round()}%', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, color: p.ok))),
                  Expanded(flex: 2, child: Text(fmtMoney(x.rev), textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w900, color: C.yel, fontSize: 12))),
                ]),
              ),
          ]),
        ),
      ]);

  // ---------- واجهة: المزيد ----------
  Widget moreTab(Pal p) => ListView(padding: const EdgeInsets.all(14), children: [
        secTitle('أسعار الرحلات', Icons.sell),
        for (final t in types) PriceRow(key: ValueKey('p${t['key']}'), t: t, onSave: price),
        const SizedBox(height: 14),
        secTitle('الزبائن المخالفون', Icons.person_off),
        if (customers.isEmpty) Text('لا يوجد زبائن مخالفون', style: TextStyle(fontSize: 12, color: p.sub)),
        for (final c in customers)
          Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
            child: Row(children: [
              Expanded(child: Text('${c['name']} · ${c['phone']} · مخالفات: ${c['strikes']}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
              SizedBox(width: 110, child: AppBtn(c['blocked'] == true ? 'فك الحظر' : 'حظر', () => blk('${c['user_id']}', c['blocked'] != true), kind: c['blocked'] == true ? BK.yellow : BK.red, vPad: 9)),
            ]),
          ),
        const SizedBox(height: 14),
        secTitle('إدارة السجل', Icons.cleaning_services),
        Text('الحذف يدوي واختياري. تُحذف الرحلات المنتهية فقط (مكتملة، مرفوضة، ملغاة، لم يحضر)، والرحلات الجارية لا تُمس أبداً. الحذف نهائي.', style: TextStyle(fontSize: 12, color: p.sub, height: 1.6)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: DropdownButton<String>(isExpanded: true, value: pgKind, items: const [DropdownMenuItem(value: 'done', child: Text('المكتملة فقط')), DropdownMenuItem(value: 'end', child: Text('كل المنتهية'))], onChanged: (v) => setState(() => pgKind = v ?? 'done'))),
          const SizedBox(width: 10),
          Expanded(child: DropdownButton<int>(isExpanded: true, value: pgDays, items: const [DropdownMenuItem(value: 30, child: Text('أقدم من 30 يوماً')), DropdownMenuItem(value: 90, child: Text('أقدم من 90 يوماً')), DropdownMenuItem(value: 180, child: Text('أقدم من 180 يوماً')), DropdownMenuItem(value: 365, child: Text('أقدم من سنة')), DropdownMenuItem(value: 0, child: Text('بدون قيد التاريخ'))], onChanged: (v) => setState(() => pgDays = v ?? 30))),
        ]),
        const SizedBox(height: 8),
        AppBtn('حذف السجل المحدد', purge, kind: BK.red, icon: Icons.delete_forever),
        const SizedBox(height: 18),
        Center(child: Text(widget.user.email ?? '', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 11, color: p.sub))),
      ]);

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    if (isAdmin != true) {
      return Directionality(textDirection: TextDirection.rtl, child: Scaffold(body: Center(child: CircularProgressIndicator(color: p.accent))));
    }
    final pages = [ridesTab(p), driversTab(p), statsTab(p), moreTab(p)];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          appHeader(context, AppKind.admin, 'لوحة الإدارة', 'تحديث مباشر', actions: [
            IconButton(onPressed: () => setDark(!p.dark), icon: Icon(p.dark ? Icons.light_mode : Icons.dark_mode, color: C.yel)),
            TextButton(style: TextButton.styleFrom(backgroundColor: C.yel, foregroundColor: C.navy), onPressed: () => sb.auth.signOut(), child: const Text('خروج', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          ]),
          Expanded(child: RefreshIndicator(onRefresh: () async { await Future.wait([loadRides(), loadDrivers(), loadCust(), loadStats()]); }, child: IndexedStack(index: tab, children: pages))),
        ]),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(color: p.head, border: const Border(top: BorderSide(color: C.yel, width: 3))),
          child: SafeArea(
            top: false,
            child: Row(children: [
              for (final (i, ic, t) in [(0, Icons.notifications_active, 'الرحلات'), (1, Icons.badge, 'السائقون'), (2, Icons.bar_chart, 'الإحصائيات'), (3, Icons.tune, 'المزيد')])
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () { click(); setState(() => tab = i); },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(color: tab == i ? C.yel.withOpacity(.16) : null, borderRadius: BorderRadius.circular(14)),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(ic, size: 22, color: tab == i ? C.yel : const Color(0xFF94A3B8)),
                        Text(t, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: tab == i ? C.yel : const Color(0xFF94A3B8))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// ============ بطاقة رحلة ============
class RideCard extends StatefulWidget {
  final Map<String, dynamic> o;
  final Map<String, String> tn;
  final Future<void> Function(dynamic, String) onStatus;
  final Future<void> Function(dynamic, String, String) onSaveDriver;
  final Future<void> Function(dynamic) onNoShow, onDelete;
  const RideCard({super.key, required this.o, required this.tn, required this.onStatus, required this.onSaveDriver, required this.onNoShow, required this.onDelete});
  @override
  State<RideCard> createState() => _RideCardState();
}

class _RideCardState extends State<RideCard> {
  late final dn = TextEditingController(text: '${widget.o['driver_name'] ?? ''}');
  late final dp = TextEditingController(text: '${widget.o['driver_phone'] ?? ''}');

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final o = widget.o;
    final st = '${o['status']}';
    final mins = (o['started_at'] != null && o['completed_at'] != null)
        ? DateTime.parse('${o['completed_at']}').difference(DateTime.parse('${o['started_at']}')).inMinutes
        : null;
    return FadeIn(
      ms: 350, dy: 10,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: st == 'جديد' ? C.yel : p.line, width: st == 'جديد' ? 1.6 : 1)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Expanded(child: Row(children: [
              Flexible(child: Text('${o['customer_name']}', overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900))),
              const SizedBox(width: 6),
              GestureDetector(onTap: () => openUrl('tel:${o['customer_phone']}'), child: Text('${o['customer_phone']}', textDirection: TextDirection.ltr, style: TextStyle(color: p.link, fontSize: 12, decoration: TextDecoration.underline))),
            ])),
            Text(fmtMoney(num.tryParse('${o['fare']}') ?? 0), style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900)),
          ]),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(99)), child: Text(widget.tn['${o['type']}'] ?? '${o['type']}', style: const TextStyle(color: C.navy, fontWeight: FontWeight.w900, fontSize: 10))),
            badge(st),
            if (o['type'] == 'shared') Text('${o['seats']} مقعد', style: TextStyle(fontSize: 11, color: p.sub)),
            Text('${o['distance_km'] ?? ''} كم', style: TextStyle(fontSize: 11, color: p.sub)),
            if (mins != null) Text('⏱ $mins د', style: TextStyle(fontSize: 11, color: p.sub)),
            Text(fmtD(o['created_at']), style: TextStyle(fontSize: 11, color: p.sub)),
          ]),
          if (o['pickup_text'] != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text('📝 ${o['pickup_text']}', style: TextStyle(fontSize: 12, color: p.sub))),
          const SizedBox(height: 6),
          Wrap(spacing: 14, children: [
            GestureDetector(onTap: () => openUrl('https://maps.google.com/?q=${o['pickup_lat']},${o['pickup_lng']}'), child: Text('📍 الانطلاق', style: TextStyle(color: p.link, fontSize: 12, decoration: TextDecoration.underline))),
            GestureDetector(onTap: () => openUrl('https://maps.google.com/?q=${o['drop_lat']},${o['drop_lng']}'), child: Text('🏁 الوجهة', style: TextStyle(color: p.link, fontSize: 12, decoration: TextDecoration.underline))),
            GestureDetector(onTap: () => openUrl('https://www.google.com/maps/dir/${o['pickup_lat']},${o['pickup_lng']}/${o['drop_lat']},${o['drop_lng']}'), child: Text('المسار', style: TextStyle(color: p.link, fontSize: 12, decoration: TextDecoration.underline))),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: dn, style: const TextStyle(fontSize: 12), decoration: inDec(context, 'اسم السائق'))),
            const SizedBox(width: 6),
            Expanded(child: TextField(controller: dp, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12), decoration: inDec(context, 'هاتف السائق'))),
            const SizedBox(width: 6),
            IconButton(onPressed: () => widget.onSaveDriver(o['id'], dn.text, dp.text), icon: const Icon(Icons.save, color: C.yel)),
          ]),
          const SizedBox(height: 8),
          if (st == 'جديد')
            Row(children: [
              Expanded(child: AppBtn('قبول', () => widget.onStatus(o['id'], 'تم القبول'), kind: BK.green, icon: Icons.check, vPad: 13)),
              const SizedBox(width: 8),
              Expanded(child: AppBtn('رفض', () => widget.onStatus(o['id'], 'مرفوضة'), kind: BK.red, icon: Icons.close, vPad: 13)),
            ])
          else
            Row(children: [
              if (st == 'السائق في الطريق' || st == 'بدأت الرحلة') ...[SizedBox(width: 110, child: AppBtn('لم يحضر', () => widget.onNoShow(o['id']), kind: BK.red, vPad: 9)), const SizedBox(width: 8)],
              Expanded(
                child: DropdownButton<String>(
                  isExpanded: true, value: allStatuses.contains(st) ? st : null, underline: const SizedBox(),
                  items: [for (final s in allStatuses) DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 12)))],
                  onChanged: (v) { if (v != null) widget.onStatus(o['id'], v); },
                ),
              ),
              if (endStatuses.contains(st)) IconButton(onPressed: () => widget.onDelete(o['id']), icon: Icon(Icons.delete_outline, color: p.sub)),
            ]),
        ]),
      ),
    );
  }
}

/// ============ بطاقة سائق (تحكم + إحصاءات + جمع الأسبوع) ============
class DriverCard extends StatefulWidget {
  final DrvStat x;
  final Map<String, dynamic>? row;
  final Map<String, String> types;
  final Future<void> Function(String, Map<String, dynamic>) onUpdate;
  final Future<void> Function(String) onDelete;
  const DriverCard({super.key, required this.x, required this.row, required this.types, required this.onUpdate, required this.onDelete});
  @override
  State<DriverCard> createState() => _DriverCardState();
}

class _DriverCardState extends State<DriverCard> {
  String open = '';
  int lim = 15;
  bool paid = false, edit = false;
  late final car = TextEditingController(text: '${widget.row?['car'] ?? ''}');
  late final plate = TextEditingController(text: '${widget.row?['plate'] ?? ''}');

  String get uid => '${widget.x.d['user_id']}';
  String get paidKey {
    final w = weekStart();
    return 'paid_${uid}_${w.year}${w.month}${w.day}';
  }

  @override
  void initState() {
    super.initState();
    Store.get(paidKey).then((v) { if (mounted) setState(() => paid = v == '1'); });
  }

  Future<void> setPaid(bool v) async {
    setState(() => paid = v);
    await Store.set(paidKey, v ? '1' : '0');
  }

  Widget stBox(Pal p, String v, String l, Color c) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(10), border: Border.all(color: p.line)),
          child: Column(children: [Text(v, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: c)), Text(l, style: TextStyle(fontSize: 10, color: p.sub, fontWeight: FontWeight.bold))]),
        ),
      );

  Widget rrow(Pal p, Map<String, dynamic> r) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(border: Border(top: BorderSide(color: p.line))),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${r['customer_name'] ?? '—'}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
            Text('${fmtD(r['created_at'])} · ${widget.types['${r['type']}'] ?? r['type'] ?? ''}${r['distance_km'] != null ? ' · ${r['distance_km']} كم' : ''}', style: TextStyle(fontSize: 10, color: p.sub)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(fmtMoney(num.tryParse('${r['fare']}') ?? 0), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)), const SizedBox(height: 2), badge('${r['status']}')]),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final x = widget.x, d = x.d;
    final row = widget.row;
    final fin = x.done + x.rej + x.can;
    final rate = fin == 0 ? null : (x.done * 100 / fin).round();
    final online = d['online'] == true, verified = d['verified'] == true;
    final list = open == 'ok' ? x.okL : x.badL;
    final dTypes = List<String>.from(row?['types'] ?? []);
    final ini = ('${d['name'] ?? '؟'}'.trim().isEmpty ? '؟' : '${d['name']}'.trim()[0]);
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: verified ? p.line : Colors.redAccent, width: verified ? 1 : 2)),
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
          child: Row(children: [
            Stack(children: [
              Container(width: 46, height: 46, alignment: Alignment.center, decoration: const BoxDecoration(color: C.yel, shape: BoxShape.circle), child: Text(ini, style: const TextStyle(color: C.navy, fontWeight: FontWeight.w900, fontSize: 19))),
              Positioned(bottom: 0, right: 0, child: Container(width: 14, height: 14, decoration: BoxDecoration(color: online ? C.green : const Color(0xFF9CA3AF), shape: BoxShape.circle, border: Border.all(color: p.card, width: 2)))),
            ]),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${d['name']}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14), overflow: TextOverflow.ellipsis),
              GestureDetector(onTap: () => openUrl('tel:${d['phone']}'), child: Text('${d['phone'] ?? ''}', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 12, color: p.link))),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: (verified ? C.green : Colors.grey).withOpacity(.16), borderRadius: BorderRadius.circular(99)), child: Text(verified ? 'مفعّل' : 'بانتظار التفعيل', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: verified ? p.ok : p.sub))),
              if (rate != null) Text('الإنجاز $rate%', style: TextStyle(fontSize: 10, color: p.sub)),
            ]),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(children: [stBox(p, '${x.t}', 'الإجمالي', p.text), const SizedBox(width: 6), stBox(p, '${x.done}', 'مكتملة', p.ok), const SizedBox(width: 6), stBox(p, '${x.rej}', 'مرفوضة', const Color(0xFFEF4444)), const SizedBox(width: 6), stBox(p, '${x.can}', 'ملغاة', const Color(0xFFF59E0B))]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (rate ?? 0) / 100, minHeight: 7, backgroundColor: p.line, color: C.green)),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('جارية: ${x.act}', style: TextStyle(fontSize: 11, color: p.sub)), Text('الإيراد الكلي: ${fmtMoney(x.rev)}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]),
        ),
        // حقل جمع الأسبوع
        Container(
          margin: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: p.dark ? const Color(0xFF111B36) : C.navy, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel.withOpacity(.6))),
          child: Column(children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('جمع الفلوس لهذا الأسبوع', style: TextStyle(color: Color(0xFFCBD5E1), fontSize: 12, fontWeight: FontWeight.bold)),
              Text(fmtMoney(x.weekRev), style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900, fontSize: 19)),
            ]),
            const SizedBox(height: 4),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${x.weekDone} رحلة مكتملة منذ السبت', style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 10)),
              GestureDetector(
                onTap: () => setPaid(!paid),
                child: Row(children: [Icon(paid ? Icons.check_circle : Icons.radio_button_unchecked, size: 18, color: paid ? C.green : const Color(0xFF94A3B8)), const SizedBox(width: 4), Text(paid ? 'تم استلام المبلغ' : 'لم يُستلم بعد', style: TextStyle(color: paid ? C.green : const Color(0xFFCBD5E1), fontSize: 11, fontWeight: FontWeight.bold))]),
              ),
            ]),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Expanded(child: _tabBtn(p, 'المقبولة (${x.okL.length})', Icons.check_circle, open == 'ok', p.ok, () => setState(() { open = open == 'ok' ? '' : 'ok'; lim = 15; }))),
            const SizedBox(width: 8),
            Expanded(child: _tabBtn(p, 'المرفوضة والملغاة (${x.badL.length})', Icons.cancel, open == 'bad', const Color(0xFFEF4444), () => setState(() { open = open == 'bad' ? '' : 'bad'; lim = 15; }))),
          ]),
        ),
        if (open.isNotEmpty) ...[
          if (list.isEmpty) Padding(padding: const EdgeInsets.all(16), child: Center(child: Text('لا توجد طلبات', style: TextStyle(fontSize: 12, color: p.sub)))),
          for (final r in list.take(lim)) rrow(p, r),
          if (list.length > lim) TextButton(onPressed: () => setState(() => lim += 15), child: Text('عرض المزيد (${list.length - lim})')),
        ],
        // التحكم بالسائق
        Container(
          decoration: BoxDecoration(border: Border(top: BorderSide(color: p.line))),
          child: Column(children: [
            InkWell(
              onTap: () => setState(() => edit = !edit),
              child: Padding(padding: const EdgeInsets.all(12), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(edit ? Icons.expand_less : Icons.settings, size: 18, color: C.yel), const SizedBox(width: 6), Text(edit ? 'إخفاء التحكم' : 'التحكم بالسائق (تفعيل / تعديل / حذف)', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12))])),
            ),
            if (edit && row != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Row(children: [
                    Expanded(child: TextField(controller: car, decoration: inDec(context, 'نوع السيارة', icon: Icons.directions_car_outlined))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: plate, decoration: inDec(context, 'رقم اللوحة', icon: Icons.pin_outlined))),
                  ]),
                  const SizedBox(height: 8),
                  AppBtn('حفظ بيانات السيارة', () => widget.onUpdate(uid, {'car': car.text.trim(), 'plate': plate.text.trim()}), kind: BK.navy, icon: Icons.save, vPad: 10),
                  const SizedBox(height: 10),
                  Text('الخطوط المسموحة:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: p.sub)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 8, runSpacing: 6, children: [
                    for (final e in widget.types.entries)
                      FilterChip(
                        label: Text(e.value, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: dTypes.contains(e.key) ? C.navy : p.text)),
                        selected: dTypes.contains(e.key), selectedColor: C.yel, backgroundColor: p.soft, checkmarkColor: C.navy,
                        onSelected: (v) { final n = [...dTypes]; v ? n.add(e.key) : n.remove(e.key); widget.onUpdate(uid, {'types': n}); },
                      ),
                  ]),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: AppBtn(verified ? 'إيقاف' : 'تفعيل', () => widget.onUpdate(uid, {'verified': !verified}), kind: verified ? BK.gray : BK.yellow, icon: verified ? Icons.pause : Icons.verified, vPad: 11)),
                    const SizedBox(width: 8),
                    SizedBox(width: 110, child: AppBtn('حذف', () => widget.onDelete(uid), kind: BK.red, icon: Icons.delete, vPad: 11)),
                  ]),
                ]),
              ),
          ]),
        ),
      ]),
    );
  }

  Widget _tabBtn(Pal p, String t, IconData i, bool on, Color c, VoidCallback f) => InkWell(
        onTap: () { click(); f(); },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 4),
          decoration: BoxDecoration(color: on ? c.withOpacity(.16) : p.card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? c : p.line)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(i, size: 15, color: c), const SizedBox(width: 4), Flexible(child: Text(t, textAlign: TextAlign.center, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: on ? c : p.text)))]),
        ),
      );
}

/// ============ سطر سعر ============
class PriceRow extends StatefulWidget {
  final Map<String, dynamic> t;
  final Future<void> Function(String, Map<String, dynamic>) onSave;
  const PriceRow({super.key, required this.t, required this.onSave});
  @override
  State<PriceRow> createState() => _PriceRowState();
}

class _PriceRowState extends State<PriceRow> {
  late final base = TextEditingController(text: '${(num.tryParse('${widget.t['base']}') ?? 0).round()}');
  late final km = TextEditingController(text: '${(num.tryParse('${widget.t['per_km']}') ?? 0).round()}');

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('${widget.t['name']}', style: const TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: base, keyboardType: TextInputType.number, decoration: inDec(context, 'أجرة البداية'))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: km, keyboardType: TextInputType.number, decoration: inDec(context, 'سعر الكم'))),
          const SizedBox(width: 6),
          IconButton(
            onPressed: () => widget.onSave('${widget.t['key']}', {'base': num.tryParse(base.text) ?? 0, 'per_km': num.tryParse(km.text) ?? 0}),
            icon: const Icon(Icons.save, color: C.yel),
          ),
        ]),
      ]),
    );
  }
}
