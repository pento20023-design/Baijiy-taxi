import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'core.dart';

const tn = {
  'provincial': 'تكسي محافظات',
  'district': 'تكسي أقضية ونواحي',
  'local': 'تكسي محلي',
  'private': 'تكسي خصوصي',
  'shared': 'تكسي عام',
};

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Boot(kind: AppKind.driver, child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (_, m, __) => MaterialApp(
          title: 'سائق تكسي بيجي',
          debugShowCheckedModeBanner: false,
          scaffoldMessengerKey: messengerKey,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: m,
          home: const DriverHome(),
        ),
      );
}

/// موقع السائق الحالي (مشترك بين الشاشة الرئيسية وشاشة الخريطة)
final ValueNotifier<LatLng?> lastPos = ValueNotifier(null);

enum V { login, reg, wait, main }

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> with WidgetsBindingObserver {
  User? user;
  Map<String, dynamic>? me;
  List<Map<String, dynamic>> rides = [];
  V view = V.login;
  bool started = false, geoOn = false, agree = false, busy = false;
  RealtimeChannel? rch;
  StreamSubscription<AuthState>? authSub;
  StreamSubscription<Position>? geoSub;
  Timer? pollT, pingT;

  final em = TextEditingController(), pw = TextEditingController();
  final rn = TextEditingController(), rPhone = TextEditingController(), rc = TextEditingController(), rp = TextEditingController();
  final regTypes = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    user = sb.auth.currentUser;
    if (user != null) init();
    authSub = sb.auth.onAuthStateChange.listen((s) {
      if (!mounted) return;
      // لا نُسجّل الخروج إلا عند الخروج الفعلي (حتى لا يُطرد السائق عند تجديد الجلسة)
      if (s.event == AuthChangeEvent.signedOut) {
        user = null;
        teardown();
        setState(() => view = V.login);
        return;
      }
      final u = s.session?.user;
      if (u == null) return;
      if (u.id == user?.id) { user = u; return; }
      user = u;
      init();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    authSub?.cancel();
    teardown();
    super.dispose();
  }

  void teardown() {
    pollT?.cancel(); pingT?.cancel(); geoSub?.cancel();
    if (rch != null) sb.removeChannel(rch!);
    rch = null; started = false; geoOn = false; me = null; rides = [];
    WakelockPlus.disable();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && me != null) { load(); wake(); }
  }

  // ---------- الحساب ----------
  Future<void> dLogin() async {
    final e = em.text.trim(), p = pw.text;
    if (e.isEmpty || p.isEmpty) return toast('أدخل البيانات');
    setState(() => busy = true);
    try { await sb.auth.signInWithPassword(email: e, password: p); } catch (x) { toast(arErr(x)); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> dSignUp() async {
    final e = em.text.trim(), p = pw.text;
    if (e.isEmpty || p.isEmpty) return toast('أدخل البيانات');
    if (!agree) return toast('يجب الموافقة على سياسة الخصوصية');
    try { await sb.auth.signUp(email: e, password: p); } catch (x) { toast(arErr(x)); }
  }

  Future<void> sendReset() async {
    final e = em.text.trim();
    if (e.isEmpty) return toast('أدخل بريدك');
    try { await sb.auth.resetPasswordForEmail(e); toast('تم إرسال رابط الاسترداد بريدياً'); } catch (x) { toast(arErr(x)); }
  }

  Future<void> delAcc() async {
    if (user == null) return toast('سجّل الدخول أولاً');
    if (!await confirmDlg(context, 'تأكيد حذف الحساب وبياناتك نهائياً؟')) return;
    try { await sb.rpc('delete_my_account'); await sb.auth.signOut(); toast('تم حذف الحساب'); } catch (e) { toast('$e'); }
  }

  Future<void> register() async {
    final name = rn.text.trim(), phone = rPhone.text.trim();
    if (name.isEmpty || phone.isEmpty || regTypes.isEmpty) return toast('يرجى ملء كافة الحقول المطلوبة');
    try {
      await sb.from('drivers').insert({'user_id': user!.id, 'name': name, 'phone': phone, 'car': rc.text.trim(), 'plate': rp.text.trim(), 'types': regTypes.toList()});
      init();
    } catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
  }

  // ---------- التهيئة ----------
  Future<void> init() async {
    try {
      me = await sb.from('drivers').select().eq('user_id', user!.id).maybeSingle();
    } catch (e) { return toast('$e'); }
    if (!mounted) return;
    if (me == null) return setState(() => view = V.reg);
    if (me!['verified'] != true) return setState(() => view = V.wait);
    setState(() => view = V.main);
    if (me!['online'] == true) wake();
    await load();
    if (started) return;
    started = true;

    rch = sb.channel('drv').onPostgresChanges(
      event: PostgresChangeEvent.all, schema: 'public', table: 'rides',
      callback: (p) {
        if (p.eventType == PostgresChangeEvent.insert) {
          final n = p.newRecord;
          final types = List<String>.from(me?['types'] ?? []);
          if (me?['online'] == true && types.contains(n['type']) && n['user_id'] != user!.id) {
            SystemSound.play(SystemSoundType.alert);
            Notifier.show('🚕 طلب جديد', '${tn[n['type']] ?? ''} · ${fmtMoney(num.parse('${n['fare']}'))}');
            toast('🚕 طلب جديد متوفر!');
          }
        }
        load();
      },
    ).subscribe();

    askGeo();
    Notifier.ask();
    pollT = Timer.periodic(const Duration(seconds: 5), (_) { if (me?['online'] == true) load(); });
    pingT = Timer.periodic(const Duration(seconds: 5), (_) {
      final a = active(), l = lastPos.value;
      if (a != null && l != null) sb.rpc('driver_ping', params: {'rid': a['id'], 'la': l.latitude, 'lo': l.longitude}).catchError((_) {});
    });
  }

  Map<String, dynamic>? active() =>
      rides.where((r) => r['driver_id'] == user?.id && !endStatuses.contains(r['status'])).firstOrNull;

  Future<void> load() async {
    if (user == null) return;
    try {
      final m = await sb.from('drivers').select().eq('user_id', user!.id).maybeSingle();
      if (m != null) {
        me = m;
        if (m['verified'] != true) { if (mounted) setState(() => view = V.wait); return; }
      }
      final data = await sb.from('rides').select().order('created_at', ascending: false).limit(30);
      if (mounted) setState(() => rides = List<Map<String, dynamic>>.from(data));
    } catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
  }

  // ---------- الموقع ----------
  Future<void> askGeo() async {
    if (await locOk()) { startGeo(); return; }
    if (!mounted) return;
    showLocDisclosure(context, 'يجمع التطبيق موقعك الدقيق أثناء فتح التطبيق فقط وخلال رحلة نشطة ويُرسله إلى الزبون ليتابع وصولك. لا يُجمع الموقع والتطبيق مغلق.', startGeo);
  }

  Future<void> startGeo() async {
    if (geoOn) return;
    geoOn = true;
    try {
      await ensureLocPermission();
      geoSub = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high))
          .listen((p) => lastPos.value = LatLng(p.latitude, p.longitude), onError: (_) => geoOn = false);
    } catch (e) {
      geoOn = false;
      toast('الموقع محظور: فعّل صلاحية الموقع للتطبيق من إعدادات الهاتف');
    }
  }

  Future<void> wake() async { try { if (me?['online'] == true) await WakelockPlus.enable(); } catch (_) {} }

  Future<void> toggleOnline() async {
    try {
      await sb.from('drivers').update({'online': !(me!['online'] == true)}).eq('user_id', user!.id);
    } catch (e) { return toast(e is PostgrestException ? e.message : '$e'); }
    setState(() => me!['online'] = !(me!['online'] == true));
    if (me!['online'] == true) { wake(); if (lastPos.value == null) startGeo(); } else { WakelockPlus.disable(); }
    load();
  }

  Future<void> acc(int id) async {
    try { await sb.rpc('accept_ride', params: {'rid': id}); toast('✅ تم استلام الطلب'); }
    catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
    load();
  }

  Future<void> setS(int id, String s) async {
    try { await sb.rpc('driver_status', params: {'rid': id, 's': s}); }
    catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
    load();
  }

  void openRide(Map<String, dynamic> r, [String? focus]) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => RideMapPage(ride: r, focus: focus ?? '')));

  // ---------- واجهة ----------
  Widget card(Pal p, List<Widget> kids, {Color? bg, Border? border}) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: bg ?? p.card, borderRadius: BorderRadius.circular(18), border: border ?? Border.all(color: C.yel.withOpacity(.5), width: 1.4)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [for (final k in kids) Padding(padding: const EdgeInsets.only(bottom: 11), child: k)]),
      );

  Widget loginView(Pal p) => FadeIn(
        child: Column(children: [
          const SizedBox(height: 10),
          const AppLogo(AppKind.driver, size: 92),
          const SizedBox(height: 12),
          const Text('سائق تكسي بيجي', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.yel)),
          const SizedBox(height: 18),
          card(p, [
            const Text('تسجيل دخول السائق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            TextField(controller: em, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: inDec(context, 'البريد الإلكتروني', icon: Icons.mail_outline)),
            TextField(controller: pw, obscureText: true, textDirection: TextDirection.ltr, decoration: inDec(context, 'كلمة السر', icon: Icons.lock_outline)),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Checkbox(value: agree, onChanged: (v) => setState(() => agree = v ?? false)),
              Expanded(child: Wrap(children: [
                const Text('عند إنشاء حساب: أوافق على ', style: TextStyle(fontSize: 12)),
                GestureDetector(onTap: () => openUrl(privacyUrl), child: Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: p.link, decoration: TextDecoration.underline))),
                const Text(' وعلى مشاركة موقعي مع الزبون أثناء الرحلة.', style: TextStyle(fontSize: 12)),
              ])),
            ]),
            Row(children: [Expanded(child: AppBtn('دخول', busy ? null : dLogin, kind: BK.yellow, vPad: 14)), const SizedBox(width: 8), Expanded(child: AppBtn('إنشاء حساب', dSignUp, kind: BK.navy, vPad: 14))]),
            TextButton(onPressed: sendReset, child: Text('استرداد كلمة السر', style: TextStyle(fontSize: 12, color: p.link, decoration: TextDecoration.underline, fontWeight: FontWeight.bold))),
          ]),
        ]),
      );

  Widget regView(Pal p) => FadeIn(
        child: card(p, [
          const Text('تسجيل بيانات السائق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          Text('يرجى ملء البيانات لتفعيل الحساب من قبل الإدارة:', style: TextStyle(fontSize: 12, color: p.sub)),
          TextField(controller: rn, decoration: inDec(context, 'الاسم الكامل', icon: Icons.person_outline)),
          TextField(controller: rPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: inDec(context, 'رقم الهاتف', icon: Icons.phone_outlined)),
          TextField(controller: rc, decoration: inDec(context, 'نوع السيارة ولونها', icon: Icons.directions_car_outlined)),
          TextField(controller: rp, decoration: inDec(context, 'رقم اللوحة', icon: Icons.pin_outlined)),
          const Text('الخطوط التي تعمل عليها:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in tn.entries)
              FilterChip(
                label: Text(e.value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12, color: regTypes.contains(e.key) ? C.navy : p.text)),
                selected: regTypes.contains(e.key),
                backgroundColor: p.soft,
                selectedColor: C.yel,
                checkmarkColor: C.navy,
                onSelected: (v) => setState(() => v ? regTypes.add(e.key) : regTypes.remove(e.key)),
              ),
          ]),
          AppBtn('إرسال للمراجعة', register, kind: BK.yellow),
        ]),
      );

  Widget waitView(Pal p) => FadeIn(
        child: card(p, [
          const Icon(Icons.hourglass_top, size: 44, color: C.yel),
          const Text('حسابك قيد المراجعة', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
          Text('سيتم تفعيل حسابك من قبل الإدارة قريباً.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: p.sub)),
          TextButton(onPressed: init, child: const Text('تحديث الحالة')),
        ]),
      );

  Widget navBox(Pal p, Map<String, dynamic> a, String w) {
    final la = w == 'p' ? a['pickup_lat'] : a['drop_lat'], lo = w == 'p' ? a['pickup_lng'] : a['drop_lng'];
    final tx = w == 'p' ? 'الزبون' : 'الوجهة';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      AppBtn('المسار إلى $tx داخل التطبيق', () => openRide(a, w), kind: BK.yellow, icon: Icons.alt_route),
      if (a['pickup_text'] != null && w == 'p')
        Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: C.night, borderRadius: BorderRadius.circular(12)), child: Text('📝 ${a['pickup_text']}', style: const TextStyle(color: Colors.white70, fontSize: 12))),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: AppBtn('Waze', () => openUrl(wazeUrl(la, lo)), kind: BK.sky)),
        const SizedBox(width: 8),
        Expanded(child: AppBtn('Google Maps', () => openUrl(gmapsUrl(la, lo)), kind: BK.white)),
      ]),
    ]);
  }

  Widget activeCard(Pal p, Map<String, dynamic> a) {
    final toPick = a['status'] != 'بدأت الرحلة';
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(color: p.dark ? const Color(0xFF111B36) : C.navy, borderRadius: BorderRadius.circular(14), border: Border.all(color: C.yel, width: 2), boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 14)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(tn[a['type']] ?? '', style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900)),
          Text(fmtMoney(num.parse('${a['fare']}')), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
        ]),
        const SizedBox(height: 10),
        Row(children: [const Icon(Icons.person, size: 16, color: C.yel), const SizedBox(width: 6), Text('${a['customer_name']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))]),
        const SizedBox(height: 10),
        AppBtn('اتصل بالزبون (${a['customer_phone']})', () => openUrl('tel:${a['customer_phone']}'), kind: BK.green, icon: Icons.phone),
        const SizedBox(height: 10),
        navBox(p, a, toPick ? 'p' : 'd'),
        const SizedBox(height: 10),
        toPick ? AppBtn('بدأت الرحلة', () => setS(a['id'], 'بدأت الرحلة'), kind: BK.yellow, vPad: 15) : AppBtn('إنهاء الرحلة', () => setS(a['id'], 'مكتملة'), kind: BK.yellow, vPad: 15),
      ]),
    );
  }

  Widget newRideCard(Pal p, Map<String, dynamic> r) => FadeIn(
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(tn[r['type']] ?? '', style: const TextStyle(fontWeight: FontWeight.w900)), Text(fmtMoney(num.parse('${r['fare']}')), style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: p.accent))]),
            const SizedBox(height: 6),
            Text('${num.parse('${r['distance_km']}')} كم ${r['type'] == 'shared' ? '· ${r['seats']} مقعد' : ''}', style: TextStyle(fontSize: 12, color: p.sub)),
            if (r['pickup_text'] != null)
              Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: p.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel.withOpacity(.4))), child: Text('📝 ${r['pickup_text']}', style: const TextStyle(fontSize: 12))),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: AppBtn('الموقع', () => openRide(r), kind: BK.white, icon: Icons.map)),
              const SizedBox(width: 8),
              Expanded(child: AppBtn('استلام الطلب', () => acc(r['id']), kind: BK.yellow)),
            ]),
          ]),
        ),
      );

  Widget mainView(Pal p) {
    final online = me?['online'] == true;
    final a = active();
    final types = List<String>.from(me?['types'] ?? []);
    final nw = online ? rides.where((r) => r['status'] == 'جديد' && types.contains(r['type']) && r['user_id'] != user!.id).toList() : <Map<String, dynamic>>[];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Material(
        color: online ? C.green : (p.dark ? const Color(0xFF2A3554) : const Color(0xFFD1D5DB)),
        borderRadius: BorderRadius.circular(14),
        elevation: 2,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () { click(); toggleOnline(); },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 18), child: Text(online ? '🟢 متصل — استلام الطلبات مفعّل' : 'غير متصل — اضغط للاتصال', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: online ? const Color(0xFF04210F) : p.text))),
        ),
      ),
      const SizedBox(height: 12),
      if (a != null) activeCard(p, a),
      if (a == null && nw.isEmpty)
        Padding(padding: const EdgeInsets.symmetric(vertical: 36), child: Text(online ? 'بانتظار طلبات جديدة...' : 'قم بالاتصال لتلقي الطلبات', textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: p.sub))),
      if (a == null) ...nw.map((r) => newRideCard(p, r)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final online = me?['online'] == true;
    Widget body;
    switch (view) {
      case V.reg: body = regView(p); break;
      case V.wait: body = waitView(p); break;
      case V.main: body = mainView(p); break;
      default: body = loginView(p);
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          appHeader(context, AppKind.driver, 'سائق تكسي بيجي', online ? 'متصل' : 'غير متصل', actions: [
            IconButton(
              tooltip: 'الوضع الليلي',
              onPressed: () => setDark(!p.dark),
              icon: Icon(p.dark ? Icons.light_mode : Icons.dark_mode, color: C.yel),
            ),
            if (view != V.login)
              TextButton(style: TextButton.styleFrom(backgroundColor: C.yel, foregroundColor: C.navy), onPressed: () => sb.auth.signOut(), child: const Text('خروج', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
          ]),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async { if (view == V.main) await load(); },
              child: ListView(padding: const EdgeInsets.all(16), children: [
                body,
                const SizedBox(height: 24),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  GestureDetector(onTap: () => openUrl(privacyUrl), child: Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, color: p.sub, decoration: TextDecoration.underline))),
                  Text('  ·  ', style: TextStyle(color: p.sub)),
                  GestureDetector(onTap: delAcc, child: Text('حذف حسابي', style: TextStyle(fontSize: 12, color: p.sub, decoration: TextDecoration.underline))),
                ]),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

String wazeUrl(a, b) => 'https://waze.com/ul?ll=$a,$b&navigate=yes&zoom=17';
String gmapsUrl(a, b) => 'https://www.google.com/maps/dir/?api=1&destination=$a,$b&travelmode=driving';

/// ============ المسار من السائق إلى الزبون / الوجهة داخل التطبيق ============
class RideMapPage extends StatefulWidget {
  final Map<String, dynamic> ride;
  final String focus;
  const RideMapPage({super.key, required this.ride, required this.focus});
  @override
  State<RideMapPage> createState() => _RideMapPageState();
}

class _RideMapPageState extends State<RideMapPage> {
  final mc = MapController();
  bool ready = false, fitted = false;
  RouteInfo? route;
  LatLng? routeFrom;
  DateTime lastFetch = DateTime(2000);

  Map<String, dynamic> get r => widget.ride;
  LatLng? pt(String la, String lo) {
    final a = double.tryParse('${r[la]}'), b = double.tryParse('${r[lo]}');
    return (a != null && b != null) ? LatLng(a, b) : null;
  }

  LatLng? get pick => pt('pickup_lat', 'pickup_lng');
  LatLng? get drop => pt('drop_lat', 'drop_lng');
  bool get toPick => widget.focus == 'p' || (widget.focus.isEmpty && r['status'] != 'بدأت الرحلة');
  LatLng? get target => toPick ? pick : drop;

  @override
  void initState() {
    super.initState();
    lastPos.addListener(refreshRoute);
    refreshRoute();
  }

  @override
  void dispose() {
    lastPos.removeListener(refreshRoute);
    super.dispose();
  }

  Future<void> refreshRoute() async {
    final from = lastPos.value ?? (toPick ? null : pick);
    final tgt = target;
    if (from == null || tgt == null) return;
    if (routeFrom != null && distKm(routeFrom!, from) < .08) return;
    if (DateTime.now().difference(lastFetch).inSeconds < 8) return;
    lastFetch = DateTime.now();
    final res = await osrmRoute(from, tgt);
    if (!mounted || res == null) return;
    setState(() { route = res; routeFrom = from; });
    if (!fitted) fit();
  }

  void fit() {
    if (!ready) return;
    final pts = <LatLng>[if (pick != null) pick!, if (widget.focus != 'p' && drop != null) drop!, if (lastPos.value != null) lastPos.value!];
    if (pts.isEmpty) return;
    if (pts.length == 1) { mc.move(pts.first, 17); return; }
    fitted = true;
    mc.fitCamera(CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.fromLTRB(50, 100, 50, 60), maxZoom: 17));
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final st = r['status'];
    final la = target?.latitude, lo = target?.longitude;
    final tx = toPick ? 'الزبون' : 'الوجهة';
    final title = st == 'جديد' ? 'طلب جديد: الانطلاق والوجهة' : (toPick ? 'المسار إلى الزبون' : 'المسار إلى الوجهة');
    final eta = route == null ? (lastPos.value == null ? 'بانتظار موقعك...' : 'جاري حساب المسار...') : '${route!.min.round().clamp(1, 999)} دقيقة · ${route!.km.toStringAsFixed(1)} كم';
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Expanded(
            child: Stack(children: [
              ValueListenableBuilder<LatLng?>(
                valueListenable: lastPos,
                builder: (_, me, __) => FlutterMap(
                  mapController: mc,
                  options: MapOptions(initialCenter: pick ?? const LatLng(34.9311, 43.4883), initialZoom: 16, onMapReady: () { ready = true; fit(); }),
                  children: [
                    TileLayer(urlTemplate: mapTiles, userAgentPackageName: 'com.baiji.driver'),
                    if (route != null) PolylineLayer(polylines: [Polyline(points: route!.pts, strokeWidth: 6, color: const Color(0xFF1A73E8), borderStrokeWidth: 2, borderColor: Colors.white)]),
                    MarkerLayer(markers: [
                      if (pick != null) Marker(point: pick!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFF16A34A), label: 'الزبون')),
                      if (drop != null) Marker(point: drop!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFFDC2626), label: 'الوجهة')),
                      if (me != null) Marker(point: me, width: 34, height: 34, child: carDot()),
                    ]),
                  ],
                ),
              ),
              SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [roundMapBtn(context, Icons.arrow_forward, () => Navigator.pop(context)), const SizedBox(width: 8), Expanded(child: mapChip(context, '$title · $eta'))]))),
              Positioned(left: 12, bottom: 14, child: roundMapBtn(context, Icons.fit_screen, fit)),
            ]),
          ),
          mapSheet(context, Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('${r['customer_name']}', style: const TextStyle(fontWeight: FontWeight.w900)), Text(fmtMoney(num.parse('${r['fare']}')), style: TextStyle(fontWeight: FontWeight.w900, color: p.accent))]),
            if (r['pickup_text'] != null)
              Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: p.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel.withOpacity(.4))), child: Text('📝 ${r['pickup_text']}', style: const TextStyle(fontSize: 12))),
            Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('🟢 الزبون · 🔴 الوجهة · 🚕 موقعك', style: TextStyle(fontSize: 12, color: p.sub))),
            if (la != null)
              Row(children: [
                Expanded(child: AppBtn('Waze إلى $tx', () => openUrl(wazeUrl(la, lo)), kind: BK.sky)),
                const SizedBox(width: 8),
                Expanded(child: AppBtn('Google Maps', () => openUrl(gmapsUrl(la, lo)), kind: BK.white)),
              ]),
          ])),
        ]),
      ),
    );
  }
}
