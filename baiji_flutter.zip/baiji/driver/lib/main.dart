import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'core.dart';

const tn = {
  'provincial': 'تكسي محافظات',
  'district': 'تكسي أقضية ونواحي',
  'local': 'تكسي محلي',
  'private': 'تكسي خصوصي',
  'shared': 'تكسي عام',
};

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (d) => FlutterError.presentError(d);
  runApp(const Boot(child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'سائق تكسي بيجي',
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: messengerKey,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: buildTheme(),
        home: const DriverHome(),
      );
}

/// موقع السائق الحالي (مشترك بين الشاشة الرئيسية وشاشة الخريطة)
final ValueNotifier<LatLng?> lastPos = ValueNotifier(null);

enum V { login, reg, wait, main }

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> with WidgetsBindingObserver {
  User? user;
  Map<String, dynamic>? me;
  List<Map<String, dynamic>> rides = [];
  V view = V.login;
  bool started = false, geoOn = false, agree = false;
  RealtimeChannel? rch;
  StreamSubscription<AuthState>? authSub;
  StreamSubscription<Position>? geoSub;
  Timer? pollT, pingT;

  final em = TextEditingController(), pw = TextEditingController();
  final rn = TextEditingController(), rPhone = TextEditingController(), rc = TextEditingController(), rp = TextEditingController();
  final regTypes = <String>{};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    user = sb.auth.currentUser;
    if (user != null) init();
    authSub = sb.auth.onAuthStateChange.listen((s) {
      final u = s.session?.user;
      if (u?.id == user?.id && u != null) return;
      user = u;
      if (u != null) { init(); } else { teardown(); setState(() => view = V.login); }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    authSub?.cancel();
    teardown();
    super.dispose();
  }

  void teardown() {
    pollT?.cancel(); pingT?.cancel(); geoSub?.cancel();
    if (rch != null) sb.removeChannel(rch!);
    rch = null; started = false; geoOn = false; me = null; rides = [];
    WakelockPlus.disable();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed && me != null) { load(); wake(); }
  }

  // ---------- الحساب ----------
  Future<void> dLogin() async {
    final e = em.text.trim(), p = pw.text;
    if (e.isEmpty || p.isEmpty) return toast('أدخل البيانات');
    try { await sb.auth.signInWithPassword(email: e, password: p); } catch (x) { toast(arErr(x)); }
  }

  Future<void> dSignUp() async {
    final e = em.text.trim(), p = pw.text;
    if (e.isEmpty || p.isEmpty) return toast('أدخل البيانات');
    if (!agree) return toast('يجب الموافقة على سياسة الخصوصية');
    try { await sb.auth.signUp(email: e, password: p); } catch (x) { toast(arErr(x)); }
  }

  Future<void> sendReset() async {
    final e = em.text.trim();
    if (e.isEmpty) return toast('أدخل بريدك');
    try { await sb.auth.resetPasswordForEmail(e); toast('تم إرسال رابط الاسترداد بريدياً'); } catch (x) { toast(arErr(x)); }
  }

  Future<void> delAcc() async {
    if (user == null) return toast('سجّل الدخول أولاً');
    if (!await confirmDlg(context, 'تأكيد حذف الحساب وبياناتك نهائياً؟')) return;
    try { await sb.rpc('delete_my_account'); await sb.auth.signOut(); toast('تم حذف الحساب'); } catch (e) { toast('$e'); }
  }

  Future<void> register() async {
    final name = rn.text.trim(), phone = rPhone.text.trim();
    if (name.isEmpty || phone.isEmpty || regTypes.isEmpty) return toast('يرجى ملء كافة الحقول المتروكة');
    try {
      await sb.from('drivers').insert({'user_id': user!.id, 'name': name, 'phone': phone, 'car': rc.text.trim(), 'plate': rp.text.trim(), 'types': regTypes.toList()});
      init();
    } catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
  }

  // ---------- التهيئة ----------
  Future<void> init() async {
    try {
      me = await sb.from('drivers').select().eq('user_id', user!.id).maybeSingle();
    } catch (e) { return toast('$e'); }
    if (!mounted) return;
    if (me == null) return setState(() => view = V.reg);
    if (me!['verified'] != true) return setState(() => view = V.wait);
    setState(() => view = V.main);
    if (me!['online'] == true) wake();
    await load();
    if (started) return;
    started = true;

    rch = sb.channel('drv').onPostgresChanges(
      event: PostgresChangeEvent.all, schema: 'public', table: 'rides',
      callback: (p) {
        if (p.eventType == PostgresChangeEvent.insert) {
          final n = p.newRecord;
          final types = List<String>.from(me?['types'] ?? []);
          if (me?['online'] == true && types.contains(n['type']) && n['user_id'] != user!.id) {
            SystemSound.play(SystemSoundType.alert);
            Notifier.show('🚕 طلب جديد', '${tn[n['type']] ?? ''} · ${num.parse('${n['fare']}')} د.ع');
            toast('🚕 طلب جديد متوفر!');
          }
        }
        load();
      },
    ).subscribe();

    askGeo();
    pollT = Timer.periodic(const Duration(seconds: 5), (_) { if (me?['online'] == true) load(); });
    pingT = Timer.periodic(const Duration(seconds: 5), (_) {
      final a = active(), l = lastPos.value;
      if (a != null && l != null) sb.rpc('driver_ping', params: {'rid': a['id'], 'la': l.latitude, 'lo': l.longitude}).catchError((_) {});
    });
  }

  Map<String, dynamic>? active() =>
      rides.where((r) => r['driver_id'] == user?.id && !endStatuses.contains(r['status'])).firstOrNull;

  Future<void> load() async {
    if (user == null) return;
    try {
      final m = await sb.from('drivers').select().eq('user_id', user!.id).maybeSingle();
      if (m != null) {
        me = m;
        if (m['verified'] != true) { if (mounted) setState(() => view = V.wait); return; }
      }
      final data = await sb.from('rides').select().order('created_at', ascending: false).limit(30);
      if (mounted) setState(() => rides = List<Map<String, dynamic>>.from(data));
    } catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
  }

  // ---------- الموقع ----------
  Future<void> askGeo() async {
    if (await locOk()) { startGeo(); return; }
    if (!mounted) return;
    showLocDisclosure(context, 'يجمع التطبيق موقعك الدقيق أثناء فتح التطبيق فقط وخلال رحلة نشطة ويُرسله إلى الزبون ليتابع وصولك. لا يُجمع الموقع والتطبيق مغلق.', startGeo);
  }

  Future<void> startGeo() async {
    if (geoOn) return;
    geoOn = true;
    try {
      await ensureLocPermission();
      geoSub = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high))
          .listen((p) => lastPos.value = LatLng(p.latitude, p.longitude), onError: (_) => geoOn = false);
    } catch (e) {
      geoOn = false;
      toast('الموقع محظور: فعّل صلاحية الموقع للتطبيق من إعدادات الهاتف');
    }
  }

  Future<void> wake() async { try { if (me?['online'] == true) await WakelockPlus.enable(); } catch (_) {} }

  Future<void> toggleOnline() async {
    Notifier.ask();
    try {
      await sb.from('drivers').update({'online': !(me!['online'] == true)}).eq('user_id', user!.id);
    } catch (e) { return toast(e is PostgrestException ? e.message : '$e'); }
    setState(() => me!['online'] = !(me!['online'] == true));
    if (me!['online'] == true) { wake(); if (lastPos.value == null) startGeo(); } else { WakelockPlus.disable(); }
    load();
  }

  Future<void> acc(int id) async {
    try { await sb.rpc('accept_ride', params: {'rid': id}); toast('✅ تم استلام الطلب'); }
    catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
    load();
  }

  Future<void> setS(int id, String s) async {
    try { await sb.rpc('driver_status', params: {'rid': id, 's': s}); }
    catch (e) { toast(e is PostgrestException ? e.message : '$e'); }
    load();
  }

  void openRide(Map<String, dynamic> r, [String? focus]) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => RideMapPage(ride: r, focus: focus ?? '')));

  // ---------- واجهة ----------
  Widget card(List<Widget> kids, {Color? bg, Border? border}) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: bg ?? Colors.white, borderRadius: BorderRadius.circular(24), border: border ?? Border.all(color: const Color(0xFFE5E7EB)), boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 10)]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [for (final k in kids) Padding(padding: const EdgeInsets.only(bottom: 10), child: k)]),
      );

  Widget loginView() => card([
        const Text('تسجيل دخول السائق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        TextField(controller: em, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: inDec('البريد الإلكتروني')),
        TextField(controller: pw, obscureText: true, textDirection: TextDirection.ltr, decoration: inDec('كلمة السر')),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Checkbox(value: agree, onChanged: (v) => setState(() => agree = v ?? false)),
          Expanded(child: Wrap(children: [
            const Text('عند إنشاء حساب: أوافق على ', style: TextStyle(fontSize: 12)),
            GestureDetector(onTap: () => openUrl(privacyUrl), child: const Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF1D4ED8), decoration: TextDecoration.underline))),
            const Text(' وعلى مشاركة موقعي مع الزبون أثناء الرحلة.', style: TextStyle(fontSize: 12)),
          ])),
        ]),
        Row(children: [Expanded(child: AppBtn('دخول', dLogin)), const SizedBox(width: 8), Expanded(child: AppBtn('إنشاء حساب', dSignUp, kind: BK.yellow))]),
        TextButton(onPressed: sendReset, child: const Text('استرداد كلمة السر', style: TextStyle(fontSize: 12, color: Color(0xFF1D4ED8), decoration: TextDecoration.underline, fontWeight: FontWeight.bold))),
      ]);

  Widget regView() => card([
        const Text('تسجيل بيانات السائق', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const Text('يرجى ملء البيانات لتفعيل الحساب من قبل الإدارة:', style: TextStyle(fontSize: 12, color: Colors.black54)),
        TextField(controller: rn, decoration: inDec('الاسم الكامل')),
        TextField(controller: rPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: inDec('رقم الهاتف')),
        TextField(controller: rc, decoration: inDec('نوع السيارة ولونها')),
        TextField(controller: rp, decoration: inDec('رقم اللوحة')),
        const Text('الخطوط التي تعمل عليها:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in tn.entries)
            FilterChip(
              label: Text(e.value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
              selected: regTypes.contains(e.key),
              backgroundColor: C.soft,
              selectedColor: C.yel,
              onSelected: (v) => setState(() => v ? regTypes.add(e.key) : regTypes.remove(e.key)),
            ),
        ]),
        AppBtn('إرسال للمراجعة', register),
      ]);

  Widget waitView() => card([
        const Icon(Icons.hourglass_top, size: 44, color: C.yel),
        const Text('حسابك قيد المراجعة', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900)),
        const Text('سيتم تفعيل حسابك من قبل الإدارة قريباً.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
        TextButton(onPressed: init, child: const Text('تحديث الحالة')),
      ]);

  Widget navBox(Map<String, dynamic> a, String w) {
    final la = w == 'p' ? a['pickup_lat'] : a['drop_lat'], lo = w == 'p' ? a['pickup_lng'] : a['drop_lng'];
    final tx = w == 'p' ? 'الزبون' : 'الوجهة';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      AppBtn('عرض موقع $tx على الخريطة', () => openRide(a, w), kind: BK.white, icon: Icons.map),
      if (a['pickup_text'] != null && w == 'p')
        Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: C.dark, borderRadius: BorderRadius.circular(12)), child: Text('📝 ${a['pickup_text']}', style: const TextStyle(color: Colors.white70, fontSize: 12))),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: AppBtn('Waze', () => openUrl(wazeUrl(la, lo)), kind: BK.sky)),
        const SizedBox(width: 8),
        Expanded(child: AppBtn('Google Maps', () => openUrl(gmapsUrl(la, lo)), kind: BK.white)),
      ]),
    ]);
  }

  Widget activeCard(Map<String, dynamic> a) {
    final toPick = a['status'] == 'السائق في الطريق';
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: C.navy, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.yel, width: 2), boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 14)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(tn[a['type']] ?? '', style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900)),
          Text('${num.parse('${a['fare']}')} د.ع', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
        ]),
        const SizedBox(height: 10),
        Row(children: [const Icon(Icons.person, size: 16, color: C.yel), const SizedBox(width: 6), Text('${a['customer_name']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))]),
        const SizedBox(height: 10),
        AppBtn('اتصل بالزبون (${a['customer_phone']})', () => openUrl('tel:${a['customer_phone']}'), kind: BK.green, icon: Icons.phone),
        const SizedBox(height: 10),
        navBox(a, toPick ? 'p' : 'd'),
        const SizedBox(height: 10),
        toPick ? AppBtn('بدأت الرحلة', () => setS(a['id'], 'بدأت الرحلة'), kind: BK.yellow) : AppBtn('إنهاء الرحلة', () => setS(a['id'], 'مكتملة'), kind: BK.yellow),
      ]),
    );
  }

  Widget newRideCard(Map<String, dynamic> r) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE5E7EB))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(tn[r['type']] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${num.parse('${r['fare']}')} د.ع', style: const TextStyle(fontWeight: FontWeight.bold, color: C.navy))]),
          const SizedBox(height: 6),
          Text('${num.parse('${r['distance_km']}')} كم ${r['type'] == 'shared' ? '· ${r['seats']} مقعد' : ''}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
          if (r['pickup_text'] != null)
            Container(margin: const EdgeInsets.only(top: 8), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFDE68A))), child: Text('📝 ${r['pickup_text']}', style: const TextStyle(fontSize: 12))),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: AppBtn('الموقع', () => openRide(r), kind: BK.white, icon: Icons.map)),
            const SizedBox(width: 8),
            Expanded(child: AppBtn('استلام الطلب', () => acc(r['id']), kind: BK.yellow)),
          ]),
        ]),
      );

  Widget mainView() {
    final online = me?['online'] == true;
    final a = active();
    final types = List<String>.from(me?['types'] ?? []);
    final nw = online ? rides.where((r) => r['status'] == 'جديد' && types.contains(r['type']) && r['user_id'] != user!.id).toList() : <Map<String, dynamic>>[];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Material(
        color: online ? const Color(0xFF16A34A) : const Color(0xFFD1D5DB),
        borderRadius: BorderRadius.circular(16),
        elevation: 2,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () { click(); toggleOnline(); },
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text(online ? '🟢 متصل — استلام الطلبات مفعّل' : 'غير متصل — اضغط للاتصال', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: online ? Colors.white : const Color(0xFF374151)))),
        ),
      ),
      const SizedBox(height: 12),
      if (a != null) activeCard(a),
      if (a == null && nw.isEmpty)
        Padding(padding: const EdgeInsets.symmetric(vertical: 32), child: Text(online ? 'بانتظار طلبات جديدة...' : 'قم بالاتصال لتلقي الطلبات', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black38))),
      if (a == null) ...nw.map(newRideCard),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final online = me?['online'] == true;
    Widget body;
    switch (view) {
      case V.reg: body = regView(); break;
      case V.wait: body = waitView(); break;
      case V.main: body = mainView(); break;
      default: body = loginView();
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Container(
            decoration: const BoxDecoration(color: C.navy, border: Border(bottom: BorderSide(color: C.yel, width: 4))),
            child: SafeArea(
              bottom: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Row(children: [
                  Container(width: 44, height: 44, decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.local_taxi, color: C.navy)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('سائق تكسي بيجي', style: TextStyle(color: C.yel, fontWeight: FontWeight.w900, height: 1)),
                    Text(online ? 'متصل' : 'غير متصل', style: const TextStyle(color: Color(0xFFD1D5DB), fontSize: 10)),
                  ])),
                  IconButton(onPressed: () => permCheck(context), icon: const Icon(Icons.notifications, color: C.yel), tooltip: 'فحص الإشعارات والموقع'),
                  if (view != V.login) TextButton(style: TextButton.styleFrom(backgroundColor: C.yel, foregroundColor: C.navy), onPressed: () => sb.auth.signOut(), child: const Text('خروج', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12))),
                ]),
              ),
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async { if (view == V.main) await load(); },
              child: ListView(padding: const EdgeInsets.all(16), children: [
                body,
                const SizedBox(height: 24),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  GestureDetector(onTap: () => openUrl(privacyUrl), child: const Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, color: Colors.black38, decoration: TextDecoration.underline))),
                  const Text('  ·  ', style: TextStyle(color: Colors.black38)),
                  GestureDetector(onTap: delAcc, child: const Text('حذف حسابي', style: TextStyle(fontSize: 12, color: Colors.black38, decoration: TextDecoration.underline))),
                ]),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

String wazeUrl(a, b) => 'https://waze.com/ul?ll=$a,$b&navigate=yes&zoom=17';
String gmapsUrl(a, b) => 'https://www.google.com/maps/dir/?api=1&destination=$a,$b&travelmode=driving';

/// ============ خريطة موقع الزبون ============
class RideMapPage extends StatefulWidget {
  final Map<String, dynamic> ride;
  final String focus;
  const RideMapPage({super.key, required this.ride, required this.focus});
  @override
  State<RideMapPage> createState() => _RideMapPageState();
}

class _RideMapPageState extends State<RideMapPage> {
  final mc = MapController();
  bool ready = false;

  Map<String, dynamic> get r => widget.ride;
  LatLng? pt(String la, String lo) {
    final a = double.tryParse('${r[la]}'), b = double.tryParse('${r[lo]}');
    return (a != null && b != null) ? LatLng(a, b) : null;
  }

  LatLng? get pick => pt('pickup_lat', 'pickup_lng');
  LatLng? get drop => pt('drop_lat', 'drop_lng');

  void fit() {
    if (!ready) return;
    final pts = <LatLng>[if (pick != null) pick!, if (widget.focus != 'p' && drop != null) drop!, if (lastPos.value != null) lastPos.value!];
    if (pts.isEmpty) return;
    if (pts.length == 1) { mc.move(pts.first, 17); return; }
    mc.fitCamera(CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.fromLTRB(50, 90, 50, 50), maxZoom: 17));
  }

  @override
  Widget build(BuildContext context) {
    final st = r['status'];
    final toPick = st == 'جديد' || st == 'تم القبول' || st == 'السائق في الطريق';
    final la = toPick ? r['pickup_lat'] : r['drop_lat'], lo = toPick ? r['pickup_lng'] : r['drop_lng'];
    final tx = toPick ? 'الزبون' : 'الوجهة';
    final title = st == 'جديد' ? 'طلب جديد: الانطلاق والوجهة' : (toPick ? 'موقع الزبون' : 'وجهة الرحلة');
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Expanded(
            child: Stack(children: [
              ValueListenableBuilder<LatLng?>(
                valueListenable: lastPos,
                builder: (_, me, __) => FlutterMap(
                  mapController: mc,
                  options: MapOptions(initialCenter: pick ?? const LatLng(34.9311, 43.4883), initialZoom: 16, onMapReady: () { ready = true; fit(); }),
                  children: [
                    TileLayer(urlTemplate: mapTiles, userAgentPackageName: 'com.baiji.driver'),
                    MarkerLayer(markers: [
                      if (pick != null) Marker(point: pick!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFF16A34A), label: 'الزبون')),
                      if (drop != null) Marker(point: drop!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFFDC2626), label: 'الوجهة')),
                      if (me != null) Marker(point: me, width: 18, height: 18, child: meDot()),
                    ]),
                  ],
                ),
              ),
              SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [roundMapBtn(Icons.arrow_forward, () => Navigator.pop(context)), const SizedBox(width: 8), Expanded(child: mapChip(title))]))),
              Positioned(left: 12, bottom: 14, child: roundMapBtn(Icons.fit_screen, fit)),
            ]),
          ),
          mapSheet(Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('${r['customer_name']}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${num.parse('${r['fare']}')} د.ع', style: const TextStyle(fontWeight: FontWeight.bold))]),
            if (r['pickup_text'] != null)
              Container(margin: const EdgeInsets.only(top: 6), padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFDE68A))), child: Text('📝 ${r['pickup_text']}', style: const TextStyle(fontSize: 12))),
            const Padding(padding: EdgeInsets.symmetric(vertical: 6), child: Text('🟢 الزبون · 🔴 الوجهة · 🔵 موقعك', style: TextStyle(fontSize: 12, color: Colors.black54))),
            Row(children: [
              Expanded(child: AppBtn('Waze إلى $tx', () => openUrl(wazeUrl(la, lo)), kind: BK.sky)),
              const SizedBox(width: 8),
              Expanded(child: AppBtn('Google Maps', () => openUrl(gmapsUrl(la, lo)), kind: BK.white)),
            ]),
            const Padding(padding: EdgeInsets.only(top: 8), child: Text('الدبوس يمثل النقطة التي حدّدها الزبون بالضبط. تطبيقات الملاحة الخارجية قد تقرّبها لأقرب شارع.', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Colors.black38))),
          ])),
        ]),
      ),
    );
  }
}
