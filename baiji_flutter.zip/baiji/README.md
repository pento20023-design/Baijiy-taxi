# تكسي بيجي — Flutter / Dart

مشروعان: `customer/` (الزبون) و `driver/` (السائق). نفس قاعدة بيانات Supabase ونفس الجداول/الدوال (rides, drivers, ride_types, accept_ride, driver_status, driver_ping, delete_my_account).

## التشغيل
```bash
cd customer   # أو driver
flutter create . --platforms=android --org com.baiji   # يولّد مجلد android
flutter pub get
flutter run
```

## إعدادات أندرويد (android/app/src/main/AndroidManifest.xml)
داخل `<manifest>` أضف:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.VIBRATE"/>
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<queries>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent>
</queries>
```
وفي `android/app/build.gradle`: `minSdkVersion 21` (أو `flutter.minSdkVersion`) و`compileSdk 34` أو أحدث.
وفي `build.gradle` ضمن `compileOptions` فعّل `coreLibraryDesugaring` (مطلوب لـ flutter_local_notifications).

## ملاحظات
- الخريطة: `flutter_map` + بلاطات OpenStreetMap بدل MapLibre. إن أردت نمط OpenFreeMap المخصص استخدم `vector_map_tiles`.
- أيقونات أنواع الرحلات: الدالة `iconFor` في customer/lib/main.dart تحوّل أسماء FontAwesome المخزنة في `ride_types.icon` إلى أيقونات Material — عدّلها حسب قيمك.
- استبدل أيقونة التطبيق عبر `flutter_launcher_icons`.
- لإعادة تعيين كلمة السر عبر الرابط داخل التطبيق: فعّل Deep Link في Supabase (Redirect URL) وفي AndroidManifest، وإلا يفتح الرابط في المتصفح.
- مفتاح Supabase المضمّن هو `anon` ويجب حمايته عبر سياسات RLS.
