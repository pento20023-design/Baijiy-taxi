import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core.dart';

/// ===== العروض: أضف عروضك هنا =====
const offers = <Map<String, String>>[
  // {'title': 'خصم 10% على الرحلات المحلية', 'desc': 'ساري حتى نهاية الشهر', 'badge': 'جديد'}
];

/// حالات الرحلة: النص + نسبة التقدم
const steps = <String, (String, double)>{
  'جديد': ('بانتظار موافقة الإدارة', .2),
  'تم القبول': ('تم قبول طلبك، جاري إرسال سائق 🚕', .45),
  'السائق في الطريق': ('السائق في الطريق إليك 🚕', .7),
  'بدأت الرحلة': ('الرحلة جارية الآن 🛣️', .9),
  'مكتملة': ('وصلت بالسلامة ✅', 1),
  'مرفوضة': ('عذراً، الطلب مرفوض ❌', 1),
  'ملغاة': ('تم إلغاء الرحلة', 1),
  'لم يحضر': ('لم يحضر الزبون', 1),
};

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Boot(kind: AppKind.customer, child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<ThemeMode>(
        valueListenable: themeMode,
        builder: (_, m, __) => MaterialApp(
          title: 'تكسي بيجي',
          debugShowCheckedModeBanner: false,
          scaffoldMessengerKey: messengerKey,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: m,
          home: const AuthGate(),
        ),
      );
}

Widget themeBtn(BuildContext c) => IconButton(
      tooltip: 'الوضع الليلي',
      onPressed: () => setDark(Theme.of(c).brightness != Brightness.dark),
      icon: Icon(Theme.of(c).brightness == Brightness.dark ? Icons.light_mode : Icons.dark_mode, color: C.yel),
    );

/// ============ بوابة تسجيل الدخول ============
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  User? user = sb.auth.currentUser;
  bool recovery = false;
  StreamSubscription<AuthState>? sub;

  @override
  void initState() {
    super.initState();
    sub = sb.auth.onAuthStateChange.listen((s) {
      if (!mounted) return;
      // لا نُسجّل الخروج إلا عند الخروج الفعلي (حتى لا يُطرد المستخدم عند تجديد الجلسة)
      if (s.event == AuthChangeEvent.passwordRecovery) {
        setState(() => recovery = true);
      } else if (s.event == AuthChangeEvent.signedOut) {
        setState(() => user = null);
      } else if (s.session != null) {
        setState(() => user = s.session!.user);
      }
    });
  }

  @override
  void dispose() { sub?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (recovery) return AuthScreen(startMode: 'recover', onRecovered: () => setState(() { recovery = false; user = sb.auth.currentUser; }));
    if (user == null) return const AuthScreen();
    return HomeShell(key: ValueKey(user!.id), user: user!);
  }
}

class AuthScreen extends StatefulWidget {
  final String startMode;
  final VoidCallback? onRecovered;
  const AuthScreen({super.key, this.startMode = 'login', this.onRecovered});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late String mode = widget.startMode;
  bool busy = false, agree = false;
  final lEmail = TextEditingController(), lPass = TextEditingController();
  final sName = TextEditingController(), sPhone = TextEditingController(), sEmail = TextEditingController(), sPass = TextEditingController();
  final fEmail = TextEditingController(), nPass = TextEditingController();

  Future<void> doLogin() async {
    final email = lEmail.text.trim(), pass = lPass.text;
    if (email.isEmpty || pass.isEmpty) return toast('أدخل البريد وكلمة السر');
    setState(() => busy = true);
    try { await sb.auth.signInWithPassword(email: email, password: pass); }
    catch (e) { toast(arErr(e)); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> doSignUp() async {
    final name = sName.text.trim(), phone = sPhone.text.trim(), email = sEmail.text.trim(), pass = sPass.text;
    if (name.isEmpty || phone.isEmpty || email.isEmpty || pass.isEmpty) return toast('أكمل جميع الحقول');
    if (!agree) return toast('يجب الموافقة على سياسة الخصوصية');
    if (!RegExp(r'^[0-9+\s]{9,15}$').hasMatch(phone)) return toast('رقم الهاتف غير صحيح');
    if (pass.length < 6) return toast('كلمة السر 6 أحرف على الأقل');
    setState(() => busy = true);
    try {
      final r = await sb.auth.signUp(email: email, password: pass, data: {'name': name, 'phone': phone});
      if (r.session == null) {
        toast('تم إنشاء الحساب — افتح بريدك واضغط رابط التأكيد ثم سجّل الدخول');
        lEmail.text = email;
        setState(() => mode = 'login');
      }
    } catch (e) { toast(arErr(e)); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> sendReset() async {
    final email = fEmail.text.trim();
    if (email.isEmpty) return toast('أدخل بريدك الإلكتروني');
    try {
      await sb.auth.resetPasswordForEmail(email);
      toast('تم إرسال رابط الاسترداد إلى بريدك');
      setState(() => mode = 'login');
    } catch (e) { toast(arErr(e)); }
  }

  Future<void> setNewPass() async {
    if (nPass.text.length < 6) return toast('كلمة السر 6 أحرف على الأقل');
    try {
      await sb.auth.updateUser(UserAttributes(password: nPass.text));
      toast('تم تغيير كلمة السر');
      widget.onRecovered?.call();
    } catch (e) { toast(arErr(e)); }
  }

  Widget card(Pal p, String title, List<Widget> kids) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: C.yel.withOpacity(.55), width: 1.5)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
          const SizedBox(height: 14),
          for (final k in kids) Padding(padding: const EdgeInsets.only(bottom: 11), child: k),
        ]),
      );

  Widget ltr(TextEditingController c, String h, IconData ic, {bool pass = false, TextInputType? type}) =>
      TextField(controller: c, obscureText: pass, keyboardType: type, textDirection: TextDirection.ltr, decoration: inDec(context, h, icon: ic));

  Widget link(Pal p, String t, String m, {Color? color}) => TextButton(
      onPressed: () => setState(() => mode = m),
      child: Text(t, style: TextStyle(color: color ?? p.accent, decoration: TextDecoration.underline, fontWeight: FontWeight.bold, fontSize: 12)));

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    Widget body;
    switch (mode) {
      case 'signup':
        body = card(p, 'إنشاء حساب جديد', [
          TextField(controller: sName, decoration: inDec(context, 'الاسم الكامل', icon: Icons.person_outline)),
          ltr(sPhone, 'رقم الهاتف  07xxxxxxxxx', Icons.phone_outlined, type: TextInputType.phone),
          ltr(sEmail, 'البريد الإلكتروني', Icons.mail_outline, type: TextInputType.emailAddress),
          ltr(sPass, 'كلمة السر (6 أحرف على الأقل)', Icons.lock_outline, pass: true),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Checkbox(value: agree, onChanged: (v) => setState(() => agree = v ?? false)),
            Expanded(child: Wrap(children: [
              const Text('أوافق على ', style: TextStyle(fontSize: 12)),
              GestureDetector(onTap: () => openUrl(privacyUrl), child: Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: p.link, decoration: TextDecoration.underline))),
              const Text(' وعلى جمع بياناتي (الاسم، الهاتف، البريد، الموقع) لتنفيذ الرحلات.', style: TextStyle(fontSize: 12)),
            ])),
          ]),
          AppBtn('إنشاء الحساب', busy ? null : doSignUp, kind: BK.yellow),
          link(p, 'لدي حساب — تسجيل الدخول', 'login'),
        ]);
        break;
      case 'forgot':
        body = card(p, 'استرداد كلمة السر', [
          Text('سنرسل رابط إعادة التعيين إلى بريدك.', style: TextStyle(fontSize: 12, color: p.sub)),
          ltr(fEmail, 'البريد الإلكتروني', Icons.mail_outline, type: TextInputType.emailAddress),
          AppBtn('إرسال الرابط', sendReset, kind: BK.yellow),
          link(p, 'رجوع', 'login'),
        ]);
        break;
      case 'recover':
        body = card(p, 'كلمة سر جديدة', [ltr(nPass, 'كلمة السر الجديدة', Icons.lock_outline, pass: true), AppBtn('حفظ', setNewPass, kind: BK.yellow)]);
        break;
      default:
        body = card(p, 'تسجيل الدخول', [
          ltr(lEmail, 'البريد الإلكتروني', Icons.mail_outline, type: TextInputType.emailAddress),
          ltr(lPass, 'كلمة السر', Icons.lock_outline, pass: true),
          AppBtn('دخول', busy ? null : doLogin, kind: BK.yellow, vPad: 14),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [link(p, 'إنشاء حساب جديد', 'signup'), link(p, 'نسيت كلمة السر؟', 'forgot', color: p.link)]),
        ]);
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(gradient: LinearGradient(colors: p.dark ? [C.night, const Color(0xFF111B36)] : [C.navy, const Color(0xFF14327A)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          child: SafeArea(
            child: Stack(children: [
              Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 380),
                    child: FadeIn(
                      child: Column(children: [
                        const AppLogo(AppKind.customer, size: 96),
                        const SizedBox(height: 14),
                        const Text('تكسي بيجي', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: C.yel)),
                        const Text('رحلات آمنة وسريعة', style: TextStyle(fontSize: 12, color: Color(0xFFCBD5E1))),
                        const SizedBox(height: 22),
                        body,
                      ]),
                    ),
                  ),
                ),
              ),
              Positioned(top: 4, left: 4, child: themeBtn(context)),
            ]),
          ),
        ),
      ),
    );
  }
}

/// ============ الشاشة الرئيسية ============
class HomeShell extends StatefulWidget {
  final User user;
  const HomeShell({super.key, required this.user});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  List<Map<String, dynamic>> types = [];
  String? sel;
  LatLng? P, D;
  int seats = 1;
  bool sending = false;
  final name = TextEditingController(), phone = TextEditingController(), note = TextEditingController();
  final formKey = GlobalKey();
  final scroll = ScrollController();
  Map<String, dynamic>? ride;
  RealtimeChannel? ch;
  bool trackerHidden = false;

  @override
  void initState() {
    super.initState();
    final md = widget.user.userMetadata ?? {};
    name.text = (md['name'] ?? '').toString();
    phone.text = (md['phone'] ?? '').toString();
    loadTypes();
    loadActive();
    Notifier.ask();
  }

  @override
  void dispose() {
    pollT?.cancel();
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> loadTypes() async {
    try {
      final data = await sb.from('ride_types').select().order('sort');
      if (mounted) setState(() => types = List<Map<String, dynamic>>.from(data));
    } catch (e) { toast('تعذر تحميل أنواع الرحلات: $e'); }
  }

  Map<String, dynamic>? get selType => types.where((t) => t['key'] == sel).firstOrNull;

  String get kmText => (P != null && D != null) ? '(${distKm(P!, D!)} كم)' : '';
  String get fareText {
    final t = selType;
    if (P == null || D == null || t == null) return '—';
    final km = distKm(P!, D!);
    final n = sel == 'shared' ? seats : 1;
    final v = (((num.parse('${t['base']}') + km * num.parse('${t['per_km']}')) * n / 250).round() * 250);
    return fmtMoney(v);
  }

  Future<void> pickPoint(bool pickup) async {
    final r = await Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => MapPickerPage(pickup: pickup, initial: (pickup ? P : D) ?? P)));
    if (r != null) setState(() { if (pickup) { P = r; } else { D = r; } });
  }

  Future<void> request() async {
    final n = name.text.trim(), ph = phone.text.trim(), nt = note.text.trim().isEmpty ? null : note.text.trim();
    if (sel == null) return toast('اختر نوع الرحلة');
    if (n.isEmpty || ph.isEmpty) return toast('أدخل الاسم ورقم الهاتف');
    if (P == null || D == null) return toast('حدد الانطلاق والوجهة');
    setState(() => sending = true);
    try {
      final data = await sb.from('rides').insert({
        'user_id': widget.user.id, 'customer_name': n, 'customer_phone': ph, 'type': sel, 'seats': seats,
        'pickup_lat': P!.latitude, 'pickup_lng': P!.longitude, 'pickup_text': nt,
        'drop_lat': D!.latitude, 'drop_lng': D!.longitude, 'drop_text': nt,
      }).select().single();
      toast('✅ تم إرسال الطلب بنجاح');
      track(data);
    } catch (e) { toast('فشل الطلب: ${e is PostgrestException ? e.message : e}'); }
    if (mounted) setState(() => sending = false);
  }

  void showStatus(Map<String, dynamic> o) {
    setState(() { ride = o; trackerHidden = false; });
    if (endStatuses.contains(o['status'])) {
      Future.delayed(const Duration(seconds: 8), () { if (mounted && ride?['id'] == o['id']) setState(() => trackerHidden = true); });
    }
  }

  Timer? pollT;

  void onRideUpdate(Map<String, dynamic> n) {
    final old = ride?['status'];
    showStatus(n);
    if (old == n['status']) return;
    Notifier.show('تكسي بيجي', (steps[n['status']]?.$1) ?? '${n['status']}');
    if (n['status'] == 'مكتملة') toast('🎉 وصلت بالسلامة!');
    if (n['status'] == 'مرفوضة') toast('تم رفض الطلب من الإدارة');
  }

  void track(Map<String, dynamic> o) {
    showStatus(o);
    if (ch != null) sb.removeChannel(ch!);
    ch = sb.channel('r${o['id']}').onPostgresChanges(
      event: PostgresChangeEvent.update, schema: 'public', table: 'rides',
      filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: o['id']),
      callback: (p) => onRideUpdate(p.newRecord),
    ).subscribe();
    // فحص دوري احتياطي حتى لو لم تعمل القناة الفورية
    pollT?.cancel();
    pollT = Timer.periodic(const Duration(seconds: 6), (_) async {
      final id = ride?['id'];
      if (id == null || endStatuses.contains(ride?['status'])) return;
      try {
        final d = await sb.from('rides').select().eq('id', id).maybeSingle();
        if (d != null && mounted) onRideUpdate(d);
      } catch (_) {}
    });
  }

  Future<void> loadActive() async {
    try {
      final data = await sb.from('rides').select().eq('user_id', widget.user.id).order('created_at', ascending: false).limit(1);
      if (data.isNotEmpty && !endStatuses.contains(data[0]['status'])) track(data[0]);
    } catch (_) {}
  }

  Future<void> cancelRide() async {
    if (!await confirmDlg(context, 'تأكيد إلغاء الرحلة؟')) return;
    try {
      final d = await sb.from('rides').update({'status': 'ملغاة'}).eq('id', ride!['id']).select();
      if (d.isEmpty) return toast('لا يمكن الإلغاء الآن');
      showStatus(d[0]);
      toast('تم إلغاء الرحلة');
    } catch (_) { toast('لا يمكن الإلغاء الآن'); }
  }

  Future<void> delAcc() async {
    if (!await confirmDlg(context, 'تأكيد حذف الحساب نهائياً؟')) return;
    try {
      await sb.rpc('delete_my_account');
      await sb.auth.signOut();
      toast('تم حذف الحساب');
    } catch (e) { toast('$e'); }
  }

  // ---------- واجهة ----------
  IconData iconFor(String fa) {
    if (fa.contains('bus')) return Icons.directions_bus;
    if (fa.contains('van') || fa.contains('shuttle')) return Icons.airport_shuttle;
    if (fa.contains('road') || fa.contains('route')) return Icons.add_road;
    if (fa.contains('city') || fa.contains('building')) return Icons.location_city;
    if (fa.contains('people') || fa.contains('users')) return Icons.groups;
    if (fa.contains('user') || fa.contains('car')) return Icons.directions_car;
    return Icons.local_taxi;
  }

  Widget typeCard(Pal p, Map<String, dynamic> t) {
    final on = sel == t['key'];
    return GestureDetector(
      onTap: () {
        click();
        setState(() => sel = t['key']);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          final c = formKey.currentContext;
          if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 300));
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          gradient: on ? const LinearGradient(colors: [Color(0xFFFFD75E), C.yel], begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
          color: on ? null : p.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: on ? C.navy : p.line, width: on ? 2 : 1.2),
        ),
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(iconFor('${t['icon']}'), size: 36, color: on ? C.navy : C.yel),
          const SizedBox(height: 6),
          Text('${t['name']}', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 13, color: on ? C.navy : p.text)),
          Text('يبدأ من ${fmtMoney(num.parse('${t['base']}'))}', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: on ? C.navy : p.sub)),
        ]),
      ),
    );
  }

  Widget locBtn(Pal p, bool pickup) {
    final v = pickup ? P : D;
    return InkWell(
      onTap: () { click(); pickPoint(pickup); },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: p.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel.withOpacity(.5))),
        child: Row(children: [
          Icon(v != null ? Icons.check_circle : (pickup ? Icons.radio_button_checked : Icons.location_on), size: 19, color: v != null || pickup ? p.ok : Colors.red),
          const SizedBox(width: 8),
          Expanded(child: Text(v != null ? (pickup ? 'تم تحديد الانطلاق' : 'تم تحديد الوجهة') : (pickup ? 'تحديد نقطة الانطلاق' : 'تحديد الوجهة'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
          Icon(Icons.chevron_left, size: 18, color: p.sub),
        ]),
      ),
    );
  }

  Widget form(Pal p) => Container(
        key: formKey,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('تفاصيل الرحلة: ${selType?['name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: inDec(context, 'الاسم الكامل', icon: Icons.person_outline)),
          const SizedBox(height: 10),
          TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: inDec(context, 'رقم الهاتف للتواصل', icon: Icons.phone_outlined)),
          const SizedBox(height: 10),
          locBtn(p, true),
          const SizedBox(height: 10),
          locBtn(p, false),
          const SizedBox(height: 10),
          TextField(controller: note, decoration: inDec(context, 'ملاحظات (مثال: قرب الجامع / معلم معروف)', icon: Icons.edit_note)),
          if (sel == 'shared') ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(color: p.card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('عدد المقاعد المطلوب:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                DropdownButton<int>(value: seats, underline: const SizedBox(), items: [for (var i = 1; i <= 4; i++) DropdownMenuItem(value: i, child: Text('$i'))], onChanged: (v) => setState(() => seats = v ?? 1)),
              ]),
            ),
          ],
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: p.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel)),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text.rich(TextSpan(children: [const TextSpan(text: 'الأجرة التقديرية: ', style: TextStyle(fontWeight: FontWeight.w900)), TextSpan(text: kmText, style: TextStyle(fontSize: 11, color: p.sub))])),
              Text(fareText, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: p.accent)),
            ]),
          ),
          const SizedBox(height: 12),
          AppBtn(sending ? 'جاري إرسال الطلب...' : 'اطلب التكسي الآن', sending ? null : request, kind: BK.yellow, vPad: 15),
        ]),
      );

  Widget homePage(Pal p) => ListView(controller: scroll, padding: EdgeInsets.fromLTRB(16, 16, 16, ride != null && !trackerHidden ? 220 : 24), children: [
        FadeIn(
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.navy, Color(0xFF111B36)]), borderRadius: BorderRadius.circular(14), border: Border.all(color: C.yel.withOpacity(.35))),
            child: const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('اختر نوع رحلتك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: C.yel)),
                Text('محلي، أقضية، محافظات وخاص', style: TextStyle(fontSize: 12, color: Color(0xFFCBD5E1))),
              ]),
              Icon(Icons.local_taxi, size: 36, color: C.yel),
            ]),
          ),
        ),
        const SizedBox(height: 16),
        if (types.isEmpty)
          const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: C.yel)))
        else
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.35,
            children: [for (final t in types) typeCard(p, t)],
          ),
        if (sel != null) ...[const SizedBox(height: 16), form(p)],
      ]);

  Widget offersPage(Pal p) => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('العروض', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 12),
        if (offers.isEmpty)
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
            child: Column(children: [const Icon(Icons.card_giftcard, size: 44, color: C.yel), const SizedBox(height: 8), Text('لا توجد عروض حالياً', style: TextStyle(fontWeight: FontWeight.bold, color: p.sub)), Text('تابعنا قريباً', style: TextStyle(fontSize: 12, color: p.sub))]),
          )
        else
          for (final o in offers)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.navy, Color(0xFF111B36)]), borderRadius: BorderRadius.circular(14), border: Border.all(color: C.yel.withOpacity(.4))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (o['badge'] != null) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(6)), child: Text(o['badge']!, style: const TextStyle(color: C.navy, fontSize: 10, fontWeight: FontWeight.w900))),
                Text(o['title'] ?? '', style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900)),
                Text(o['desc'] ?? '', style: const TextStyle(color: Color(0xFFCBD5E1), fontSize: 12)),
              ]),
            ),
      ]);

  Widget settingTile(Pal p, Color bg, Color fg, IconData ic, String t, String sub, VoidCallback f, {Widget? trailing}) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: () { click(); f(); },
          borderRadius: BorderRadius.circular(14),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
            child: Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Icon(ic, color: fg)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontWeight: FontWeight.w900)), Text(sub, style: TextStyle(fontSize: 12, color: p.sub))])),
              trailing ?? Icon(Icons.chevron_left, size: 18, color: p.sub),
            ]),
          ),
        ),
      );

  Widget settingsPage(Pal p) => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('الإعدادات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 12),
        settingTile(p, C.green, const Color(0xFF04210F), Icons.chat, 'الدعم الفني', 'تواصل معنا عبر واتساب', () => openUrl('https://wa.me/9647807750432')),
        settingTile(p, C.navy, C.yel, p.dark ? Icons.dark_mode : Icons.light_mode, 'الوضع الليلي', p.dark ? 'مفعّل' : 'غير مفعّل', () => setDark(!p.dark),
            trailing: Switch(value: p.dark, activeColor: C.yel, onChanged: (v) => setDark(v))),
        const SizedBox(height: 16),
        Center(child: Text(widget.user.email ?? '', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 11, color: p.sub))),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (final (t, f) in [('تسجيل الخروج', () => sb.auth.signOut()), ('الخصوصية', () => openUrl(privacyUrl)), ('حذف حسابي', delAcc)])
            TextButton(onPressed: f, child: Text(t, style: TextStyle(fontSize: 12, color: p.sub, decoration: TextDecoration.underline))),
        ]),
      ]);

  Widget tracker(Pal p) {
    final o = ride!;
    final s = steps[o['status']] ?? ('${o['status']}', .5);
    final hasDrv = o['driver_name'] != null && !endStatuses.contains(o['status']);
    return Positioned(
      left: 14, right: 14, bottom: 8,
      child: FadeIn(
        dy: 30,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: p.dark ? const Color(0xFF111B36) : C.navy, borderRadius: BorderRadius.circular(14), border: Border.all(color: C.yel, width: 2), boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 16)]),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('متابعة الرحلة مباشرة', style: TextStyle(fontSize: 10, color: C.yel, fontWeight: FontWeight.bold)),
              Flexible(child: Text(s.$1, style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w800))),
            ]),
            if (hasDrv)
              Container(
                margin: const EdgeInsets.only(top: 8),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: C.night, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel.withOpacity(.3))),
                child: Row(children: [
                  const Icon(Icons.badge, size: 16, color: C.yel), const SizedBox(width: 6),
                  Text('السائق: ${o['driver_name']} · ', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  GestureDetector(onTap: () => openUrl('tel:${o['driver_phone']}'), child: Text('${o['driver_phone'] ?? ''}', textDirection: TextDirection.ltr, style: const TextStyle(color: C.yel, fontSize: 12, fontWeight: FontWeight.bold, decoration: TextDecoration.underline))),
                ]),
              ),
            const SizedBox(height: 12),
            ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: s.$2, minHeight: 10, backgroundColor: C.night, color: C.yel)),
            if (hasDrv || o['status'] == 'تم القبول') ...[const SizedBox(height: 12), AppBtn('تتبع الرحلة على الخريطة', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrackPage(ride: o))), kind: BK.yellow, icon: Icons.route, vPad: 10)],
            if (o['status'] == 'جديد') ...[const SizedBox(height: 12), AppBtn('إلغاء الرحلة', cancelRide, kind: BK.red, vPad: 9)],
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final pages = [homePage(p), offersPage(p), settingsPage(p)];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          appHeader(context, AppKind.customer, 'تكسي بيجي', 'رحلات آمنة وسريعة', actions: [themeBtn(context)]),
          Expanded(child: Stack(children: [
            Positioned.fill(child: IndexedStack(index: tab, children: pages)),
            if (ride != null && !trackerHidden) tracker(p),
          ])),
        ]),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(color: p.head, border: const Border(top: BorderSide(color: C.yel, width: 3))),
          child: SafeArea(
            top: false,
            child: Row(children: [
              for (final (i, ic, t) in [(0, Icons.local_taxi, 'الرئيسية'), (1, Icons.sell, 'العروض'), (2, Icons.settings, 'الإعدادات')])
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () { click(); setState(() => tab = i); },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 220),
                      margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(color: tab == i ? C.yel.withOpacity(.16) : null, borderRadius: BorderRadius.circular(14)),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(ic, size: 22, color: tab == i ? C.yel : const Color(0xFF94A3B8)),
                        Text(t, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: tab == i ? C.yel : const Color(0xFF94A3B8))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// ============ تتبع السائق ومسار الرحلة على الخريطة ============
class TrackPage extends StatefulWidget {
  final Map<String, dynamic> ride;
  const TrackPage({super.key, required this.ride});
  @override
  State<TrackPage> createState() => _TrackPageState();
}

class _TrackPageState extends State<TrackPage> {
  final mc = MapController();
  late Map<String, dynamic> r = widget.ride;
  RealtimeChannel? ch;
  RouteInfo? route;
  LatLng? routeFrom;
  String routeTarget = '';
  DateTime lastFetch = DateTime(2000);
  bool fitted = false, ready = false;

  LatLng? pt(String la, String lo) {
    final a = double.tryParse('${r[la]}'), b = double.tryParse('${r[lo]}');
    return (a != null && b != null) ? LatLng(a, b) : null;
  }

  LatLng? get pick => pt('pickup_lat', 'pickup_lng');
  LatLng? get drop => pt('drop_lat', 'drop_lng');
  LatLng? get drv => driverPosOf(r);
  bool get started => r['status'] == 'بدأت الرحلة';

  @override
  void initState() {
    super.initState();
    ch = sb.channel('trk${r['id']}').onPostgresChanges(
      event: PostgresChangeEvent.update, schema: 'public', table: 'rides',
      filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: r['id']),
      callback: (p) { if (mounted) { setState(() => r = p.newRecord); refreshRoute(); } },
    ).subscribe();
    // تحديث دوري احتياطي لموقع السائق
    poll = Timer.periodic(const Duration(seconds: 6), (_) async {
      try {
        final d = await sb.from('rides').select().eq('id', r['id']).maybeSingle();
        if (d != null && mounted) { setState(() => r = d); refreshRoute(); }
      } catch (_) {}
    });
    refreshRoute();
  }

  Timer? poll;

  @override
  void dispose() {
    poll?.cancel();
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> refreshRoute() async {
    final d = drv;
    final target = started ? drop : pick;
    final from = d ?? (started ? pick : pick);
    final tgt = d != null ? target : drop;
    final key = '${d != null}-${started}';
    if (from == null || tgt == null) return;
    final moved = routeFrom == null || distKm(routeFrom!, from) > .08 || routeTarget != key;
    if (!moved || DateTime.now().difference(lastFetch).inSeconds < 8) return;
    lastFetch = DateTime.now();
    final res = await osrmRoute(from, tgt);
    if (!mounted || res == null) return;
    setState(() { route = res; routeFrom = from; routeTarget = key; });
    if (!fitted && ready) fit();
  }

  void fit() {
    final pts = <LatLng>[if (pick != null) pick!, if (drop != null) drop!, if (drv != null) drv!];
    if (pts.length < 2) { if (pts.isNotEmpty) mc.move(pts.first, 16); return; }
    fitted = true;
    mc.fitCamera(CameraFit.coordinates(coordinates: pts, padding: const EdgeInsets.fromLTRB(50, 100, 50, 60), maxZoom: 17));
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final s = steps[r['status']] ?? ('${r['status']}', .5);
    final eta = route == null ? null : '${route!.min.round().clamp(1, 999)} دقيقة · ${route!.km.toStringAsFixed(1)} كم';
    final chip = drv == null ? 'بانتظار موقع السائق...' : (started ? 'إلى الوجهة: $eta' : 'السائق يصل خلال: $eta');
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Expanded(
            child: Stack(children: [
              FlutterMap(
                mapController: mc,
                options: MapOptions(initialCenter: pick ?? const LatLng(34.9311, 43.4883), initialZoom: 15, onMapReady: () { ready = true; fit(); }),
                children: [
                  TileLayer(urlTemplate: mapTiles, userAgentPackageName: 'com.baiji.customer'),
                  if (route != null) PolylineLayer(polylines: [Polyline(points: route!.pts, strokeWidth: 6, color: const Color(0xFF1A73E8), borderStrokeWidth: 2, borderColor: Colors.white)]),
                  MarkerLayer(markers: [
                    if (pick != null) Marker(point: pick!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFF16A34A), label: 'الانطلاق')),
                    if (drop != null) Marker(point: drop!, width: 90, height: 80, alignment: Alignment.topCenter, child: pinIcon(const Color(0xFFDC2626), label: 'الوجهة')),
                    if (drv != null) Marker(point: drv!, width: 34, height: 34, child: carDot()),
                  ]),
                ],
              ),
              SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [roundMapBtn(context, Icons.arrow_forward, () => Navigator.pop(context)), const SizedBox(width: 8), Expanded(child: mapChip(context, chip))]))),
              Positioned(left: 12, bottom: 14, child: roundMapBtn(context, Icons.fit_screen, fit)),
            ]),
          ),
          mapSheet(context, Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w900)),
            if (r['driver_name'] != null) ...[
              const SizedBox(height: 8),
              Row(children: [
                const Icon(Icons.badge, size: 18, color: C.yel), const SizedBox(width: 6),
                Expanded(child: Text('السائق: ${r['driver_name']}', style: const TextStyle(fontWeight: FontWeight.bold))),
                if (r['driver_phone'] != null) SizedBox(width: 130, child: AppBtn('اتصال', () => openUrl('tel:${r['driver_phone']}'), kind: BK.green, icon: Icons.phone, vPad: 9)),
              ]),
            ],
            const SizedBox(height: 6),
            Text(drv == null ? 'سيظهر موقع السائق على الخريطة فور بدء إرساله.' : '🟢 الانطلاق · 🔴 الوجهة · 🚕 السائق', style: TextStyle(fontSize: 11, color: p.sub)),
          ])),
        ]),
      ),
    );
  }
}

/// ============ شاشة اختيار الموقع على الخريطة ============
class MapPickerPage extends StatefulWidget {
  final bool pickup;
  final LatLng? initial;
  const MapPickerPage({super.key, required this.pickup, this.initial});
  @override
  State<MapPickerPage> createState() => _MapPickerPageState();
}

class _MapPickerPageState extends State<MapPickerPage> {
  static const c0 = LatLng(34.9311, 43.4883);
  final mc = MapController();
  bool lift = false;
  LatLng? me;
  late final LatLng start = widget.initial ?? c0;

  @override
  void initState() {
    super.initState();
    if (widget.pickup && widget.initial == null) WidgetsBinding.instance.addPostFrameCallback((_) => gps());
  }

  Future<void> gps() async {
    if (!await locOk()) {
      if (!mounted) return;
      showLocDisclosure(context, 'يستخدم التطبيق موقعك الدقيق أثناء استخدامك له فقط لتحديد نقطة الانطلاق على الخريطة، ويُرسل مع طلبك إلى الإدارة والسائق الذي يستلم رحلتك.\n\nلا نجمع الموقع والتطبيق مغلق.', gps);
      return;
    }
    try {
      final p = await getPos();
      final ll = LatLng(p.latitude, p.longitude);
      setState(() => me = ll);
      mc.move(ll, 17);
    } catch (e) { if (mounted) locFix(context, e); }
  }

  @override
  Widget build(BuildContext context) {
    final p = Pal.of(context);
    final color = widget.pickup ? const Color(0xFF16A34A) : const Color(0xFFDC2626);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Expanded(
            child: Stack(children: [
              FlutterMap(
                mapController: mc,
                options: MapOptions(
                  initialCenter: start,
                  initialZoom: widget.initial == null ? 14 : 16,
                  onMapEvent: (e) {
                    if (e is MapEventMoveStart && !lift) setState(() => lift = true);
                    if ((e is MapEventMoveEnd || e is MapEventFlingAnimationEnd) && lift) setState(() => lift = false);
                  },
                ),
                children: [
                  TileLayer(urlTemplate: mapTiles, userAgentPackageName: 'com.baiji.customer'),
                  if (me != null) MarkerLayer(markers: [Marker(point: me!, width: 18, height: 18, child: meDot())]),
                ],
              ),
              IgnorePointer(
                child: Stack(children: [
                  Center(child: Container(width: 16, height: 6, decoration: BoxDecoration(color: const Color(0x4D000000), borderRadius: BorderRadius.circular(8)))),
                  Center(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      transform: Matrix4.translationValues(0, lift ? -43 : -29, 0),
                      child: Icon(Icons.location_on, size: 58, color: color, shadows: const [Shadow(color: Color(0x59000000), blurRadius: 4, offset: Offset(0, 4))]),
                    ),
                  ),
                ]),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    roundMapBtn(context, Icons.arrow_forward, () => Navigator.pop(context)),
                    const SizedBox(width: 8),
                    Expanded(child: mapChip(context, widget.pickup ? 'حدد نقطة الانطلاق' : 'حدد الوجهة')),
                  ]),
                ),
              ),
              Positioned(left: 12, bottom: 14, child: roundMapBtn(context, Icons.my_location, gps)),
            ]),
          ),
          mapSheet(context, Column(mainAxisSize: MainAxisSize.min, children: [
            Text('حرّك الخريطة حتى يستقر الدبوس على المكان بالضبط', style: TextStyle(fontSize: 12, color: p.sub)),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: AppBtn('تأكيد الموقع', () => Navigator.pop(context, mc.camera.center), kind: BK.yellow, icon: Icons.check_circle, vPad: 14)),
          ])),
        ]),
      ),
    );
  }
}
