import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core.dart';

/// ===== العروض: أضف عروضك هنا =====
const offers = <Map<String, String>>[
  // {'title': 'خصم 10% على الرحلات المحلية', 'desc': 'ساري حتى نهاية الشهر', 'badge': 'جديد'}
];

/// حالات الرحلة: النص + نسبة التقدم
const steps = <String, (String, double)>{
  'جديد': ('بانتظار موافقة الإدارة', .2),
  'تم القبول': ('تم قبول طلبك، جاري إرسال سائق 🚕', .45),
  'السائق في الطريق': ('السائق في الطريق إليك 🚕', .7),
  'بدأت الرحلة': ('الرحلة جارية الآن 🛣️', .9),
  'مكتملة': ('وصلت بالسلامة ✅', 1),
  'مرفوضة': ('عذراً، الطلب مرفوض ❌', 1),
  'ملغاة': ('تم إلغاء الرحلة', 1),
  'لم يحضر': ('لم يحضر الزبون', 1),
};

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (d) => FlutterError.presentError(d);
  runApp(const Boot(child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'تكسي بيجي',
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: messengerKey,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: buildTheme(),
        home: const AuthGate(),
      );
}

/// ============ بوابة تسجيل الدخول ============
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});
  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  User? user = sb.auth.currentUser;
  bool recovery = false;
  StreamSubscription<AuthState>? sub;

  @override
  void initState() {
    super.initState();
    sub = sb.auth.onAuthStateChange.listen((s) {
      if (!mounted) return;
      setState(() {
        if (s.event == AuthChangeEvent.passwordRecovery) {
          recovery = true;
        } else {
          user = s.session?.user;
        }
      });
    });
  }

  @override
  void dispose() { sub?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (recovery) return AuthScreen(startMode: 'recover', onRecovered: () => setState(() { recovery = false; user = sb.auth.currentUser; }));
    if (user == null) return const AuthScreen();
    return HomeShell(key: ValueKey(user!.id), user: user!);
  }
}

class AuthScreen extends StatefulWidget {
  final String startMode;
  final VoidCallback? onRecovered;
  const AuthScreen({super.key, this.startMode = 'login', this.onRecovered});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late String mode = widget.startMode;
  bool busy = false, agree = false;
  final lEmail = TextEditingController(), lPass = TextEditingController();
  final sName = TextEditingController(), sPhone = TextEditingController(), sEmail = TextEditingController(), sPass = TextEditingController();
  final fEmail = TextEditingController(), nPass = TextEditingController();

  Future<void> doLogin() async {
    final email = lEmail.text.trim(), pass = lPass.text;
    if (email.isEmpty || pass.isEmpty) return toast('أدخل البريد وكلمة السر');
    setState(() => busy = true);
    try { await sb.auth.signInWithPassword(email: email, password: pass); }
    catch (e) { toast(arErr(e)); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> doSignUp() async {
    final name = sName.text.trim(), phone = sPhone.text.trim(), email = sEmail.text.trim(), pass = sPass.text;
    if (name.isEmpty || phone.isEmpty || email.isEmpty || pass.isEmpty) return toast('أكمل جميع الحقول');
    if (!agree) return toast('يجب الموافقة على سياسة الخصوصية');
    if (!RegExp(r'^[0-9+\s]{9,15}$').hasMatch(phone)) return toast('رقم الهاتف غير صحيح');
    if (pass.length < 6) return toast('كلمة السر 6 أحرف على الأقل');
    setState(() => busy = true);
    try {
      final r = await sb.auth.signUp(email: email, password: pass, data: {'name': name, 'phone': phone});
      if (r.session == null) {
        toast('تم إنشاء الحساب — افتح بريدك واضغط رابط التأكيد ثم سجّل الدخول');
        lEmail.text = email;
        setState(() => mode = 'login');
      }
    } catch (e) { toast(arErr(e)); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> sendReset() async {
    final email = fEmail.text.trim();
    if (email.isEmpty) return toast('أدخل بريدك الإلكتروني');
    try {
      await sb.auth.resetPasswordForEmail(email);
      toast('تم إرسال رابط الاسترداد إلى بريدك');
      setState(() => mode = 'login');
    } catch (e) { toast(arErr(e)); }
  }

  Future<void> setNewPass() async {
    if (nPass.text.length < 6) return toast('كلمة السر 6 أحرف على الأقل');
    try {
      await sb.auth.updateUser(UserAttributes(password: nPass.text));
      toast('تم تغيير كلمة السر');
      widget.onRecovered?.call();
    } catch (e) { toast(arErr(e)); }
  }

  Widget card(String title, List<Widget> kids) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: C.yel, width: 2)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(height: 12),
          for (final k in kids) Padding(padding: const EdgeInsets.only(bottom: 10), child: k),
        ]),
      );

  Widget ltr(TextEditingController c, String h, {bool pass = false, TextInputType? type}) =>
      TextField(controller: c, obscureText: pass, keyboardType: type, textDirection: TextDirection.ltr, decoration: inDec(h));

  Widget link(String t, String m, {Color color = C.navy}) => TextButton(
      onPressed: () => setState(() => mode = m),
      child: Text(t, style: TextStyle(color: color, decoration: TextDecoration.underline, fontWeight: FontWeight.bold, fontSize: 12)));

  @override
  Widget build(BuildContext context) {
    Widget body;
    switch (mode) {
      case 'signup':
        body = card('إنشاء حساب جديد', [
          TextField(controller: sName, decoration: inDec('الاسم الكامل')),
          ltr(sPhone, 'رقم الهاتف  07xxxxxxxxx', type: TextInputType.phone),
          ltr(sEmail, 'البريد الإلكتروني', type: TextInputType.emailAddress),
          ltr(sPass, 'كلمة السر (6 أحرف على الأقل)', pass: true),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Checkbox(value: agree, onChanged: (v) => setState(() => agree = v ?? false)),
            Expanded(child: Wrap(children: [
              const Text('أوافق على ', style: TextStyle(fontSize: 12)),
              GestureDetector(onTap: () => openUrl(privacyUrl), child: const Text('سياسة الخصوصية', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF1D4ED8), decoration: TextDecoration.underline))),
              const Text(' وعلى جمع بياناتي (الاسم، الهاتف، البريد، الموقع) لتنفيذ الرحلات.', style: TextStyle(fontSize: 12)),
            ])),
          ]),
          AppBtn('إنشاء الحساب', busy ? null : doSignUp, kind: BK.yellow),
          link('لدي حساب — تسجيل الدخول', 'login'),
        ]);
        break;
      case 'forgot':
        body = card('استرداد كلمة السر', [
          const Text('سنرسل رابط إعادة التعيين إلى بريدك.', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ltr(fEmail, 'البريد الإلكتروني', type: TextInputType.emailAddress),
          AppBtn('إرسال الرابط', sendReset),
          link('رجوع', 'login'),
        ]);
        break;
      case 'recover':
        body = card('كلمة سر جديدة', [ltr(nPass, 'كلمة السر الجديدة', pass: true), AppBtn('حفظ', setNewPass)]);
        break;
      default:
        body = card('تسجيل الدخول', [
          ltr(lEmail, 'البريد الإلكتروني', type: TextInputType.emailAddress),
          ltr(lPass, 'كلمة السر', pass: true),
          AppBtn('دخول', busy ? null : doLogin),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [link('إنشاء حساب جديد', 'signup'), link('نسيت كلمة السر؟', 'forgot', color: const Color(0xFF1D4ED8))]),
        ]);
    }
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: C.navy,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 380),
                child: Column(children: [
                  Container(
                    width: 96, height: 96,
                    decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(24), border: Border.all(color: C.yel, width: 4)),
                    child: const Icon(Icons.local_taxi, size: 52, color: C.navy),
                  ),
                  const SizedBox(height: 12),
                  const Text('تكسي بيجي', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: C.yel)),
                  const Text('رحلات آمنة وسريعة', style: TextStyle(fontSize: 12, color: Color(0xFFD1D5DB))),
                  const SizedBox(height: 20),
                  body,
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// ============ الشاشة الرئيسية ============
class HomeShell extends StatefulWidget {
  final User user;
  const HomeShell({super.key, required this.user});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  List<Map<String, dynamic>> types = [];
  String? sel;
  LatLng? P, D;
  int seats = 1;
  bool sending = false;
  final name = TextEditingController(), phone = TextEditingController(), note = TextEditingController();
  final formKey = GlobalKey();
  final scroll = ScrollController();
  Map<String, dynamic>? ride;
  RealtimeChannel? ch;
  bool trackerHidden = false;

  @override
  void initState() {
    super.initState();
    final md = widget.user.userMetadata ?? {};
    name.text = (md['name'] ?? '').toString();
    phone.text = (md['phone'] ?? '').toString();
    loadTypes();
    loadActive();
  }

  @override
  void dispose() {
    if (ch != null) sb.removeChannel(ch!);
    super.dispose();
  }

  Future<void> loadTypes() async {
    try {
      final data = await sb.from('ride_types').select().order('sort');
      if (mounted) setState(() => types = List<Map<String, dynamic>>.from(data));
    } catch (e) { toast('تعذر تحميل أنواع الرحلات: $e'); }
  }

  Map<String, dynamic>? get selType => types.where((t) => t['key'] == sel).firstOrNull;

  String get kmText => (P != null && D != null) ? '(${distKm(P!, D!)} كم)' : '';
  String get fareText {
    final t = selType;
    if (P == null || D == null || t == null) return '—';
    final km = distKm(P!, D!);
    final n = sel == 'shared' ? seats : 1;
    final v = (((num.parse('${t['base']}') + km * num.parse('${t['per_km']}')) * n / 250).round() * 250);
    return '$v د.ع';
  }

  Future<void> pickPoint(bool pickup) async {
    final r = await Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => MapPickerPage(pickup: pickup, initial: (pickup ? P : D) ?? P)));
    if (r != null) setState(() { if (pickup) { P = r; } else { D = r; } });
  }

  Future<void> request() async {
    Notifier.ask();
    final n = name.text.trim(), ph = phone.text.trim(), nt = note.text.trim().isEmpty ? null : note.text.trim();
    if (sel == null) return toast('اختر نوع الرحلة');
    if (n.isEmpty || ph.isEmpty) return toast('أدخل الاسم ورقم الهاتف');
    if (P == null || D == null) return toast('حدد الانطلاق والوجهة');
    setState(() => sending = true);
    try {
      final data = await sb.from('rides').insert({
        'user_id': widget.user.id, 'customer_name': n, 'customer_phone': ph, 'type': sel, 'seats': seats,
        'pickup_lat': P!.latitude, 'pickup_lng': P!.longitude, 'pickup_text': nt,
        'drop_lat': D!.latitude, 'drop_lng': D!.longitude, 'drop_text': nt,
      }).select().single();
      toast('✅ تم إرسال الطلب بنجاح');
      track(data);
    } catch (e) { toast('فشل الطلب: ${e is PostgrestException ? e.message : e}'); }
    if (mounted) setState(() => sending = false);
  }

  void showStatus(Map<String, dynamic> o) {
    setState(() { ride = o; trackerHidden = false; });
    if (endStatuses.contains(o['status'])) {
      Future.delayed(const Duration(seconds: 8), () { if (mounted && ride?['id'] == o['id']) setState(() => trackerHidden = true); });
    }
  }

  void track(Map<String, dynamic> o) {
    showStatus(o);
    if (ch != null) sb.removeChannel(ch!);
    ch = sb.channel('r${o['id']}').onPostgresChanges(
      event: PostgresChangeEvent.update, schema: 'public', table: 'rides',
      filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: o['id']),
      callback: (p) {
        final n = p.newRecord;
        showStatus(n);
        Notifier.show('تكسي بيجي', (steps[n['status']]?.$1) ?? '${n['status']}');
        if (n['status'] == 'مكتملة') toast('🎉 وصلت بالسلامة!');
        if (n['status'] == 'مرفوضة') toast('تم رفض الطلب من الإدارة');
      },
    ).subscribe();
  }

  Future<void> loadActive() async {
    try {
      final data = await sb.from('rides').select().eq('user_id', widget.user.id).order('created_at', ascending: false).limit(1);
      if (data.isNotEmpty && !endStatuses.contains(data[0]['status'])) track(data[0]);
    } catch (_) {}
  }

  Future<void> cancelRide() async {
    if (!await confirmDlg(context, 'تأكيد إلغاء الرحلة؟')) return;
    try {
      final d = await sb.from('rides').update({'status': 'ملغاة'}).eq('id', ride!['id']).select();
      if (d.isEmpty) return toast('لا يمكن الإلغاء الآن');
      showStatus(d[0]);
      toast('تم إلغاء الرحلة');
    } catch (_) { toast('لا يمكن الإلغاء الآن'); }
  }

  Future<void> delAcc() async {
    if (!await confirmDlg(context, 'تأكيد حذف الحساب نهائياً؟')) return;
    try {
      await sb.rpc('delete_my_account');
      await sb.auth.signOut();
      toast('تم حذف الحساب');
    } catch (e) { toast('$e'); }
  }

  // ---------- واجهة ----------
  Widget typesGrid() => GridView.count(
        shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.35,
        children: [
          for (var i = 0; i < types.length; i++) typeCard(types[i]),
        ],
      );

  Widget typeCard(Map<String, dynamic> t) {
    final on = sel == t['key'];
    return GestureDetector(
      onTap: () {
        click();
        setState(() => sel = t['key']);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          final c = formKey.currentContext;
          if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 300));
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          gradient: on ? const LinearGradient(colors: [Color(0xFFFFD54F), Color(0xFFFFB300)], begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
          color: on ? null : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: on ? C.navy : const Color(0x330B1F4B), width: 2),
          boxShadow: const [BoxShadow(color: Color(0x140B1F4B), blurRadius: 12, offset: Offset(0, 4))],
        ),
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(iconFor('${t['icon']}'), size: 34, color: C.navy),
          const SizedBox(height: 4),
          Text('${t['name']}', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          Text('يبدأ من ${num.parse('${t['base']}').round()} د.ع', style: const TextStyle(fontSize: 10, color: Colors.black54)),
        ]),
      ),
    );
  }

  /// يحوّل اسم أيقونة FontAwesome المخزّن في قاعدة البيانات إلى أيقونة Material
  IconData iconFor(String fa) {
    if (fa.contains('bus')) return Icons.directions_bus;
    if (fa.contains('van') || fa.contains('shuttle')) return Icons.airport_shuttle;
    if (fa.contains('road') || fa.contains('route')) return Icons.add_road;
    if (fa.contains('city') || fa.contains('building')) return Icons.location_city;
    if (fa.contains('user') || fa.contains('car')) return Icons.directions_car;
    if (fa.contains('people') || fa.contains('users')) return Icons.groups;
    return Icons.local_taxi;
  }

  Widget locBtn(bool pickup) {
    final v = pickup ? P : D;
    return InkWell(
      onTap: () { click(); pickPoint(pickup); },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFDE68A))),
        child: Row(children: [
          Icon(v != null ? Icons.check_circle : (pickup ? Icons.radio_button_checked : Icons.location_on), size: 18, color: v != null || pickup ? const Color(0xFF16A34A) : Colors.red),
          const SizedBox(width: 8),
          Expanded(child: Text(v != null ? (pickup ? 'تم تحديد الانطلاق' : 'تم تحديد الوجهة') : (pickup ? 'تحديد نقطة الانطلاق' : 'تحديد الوجهة'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
          const Icon(Icons.chevron_left, size: 18),
        ]),
      ),
    );
  }

  Widget form() => Container(
        key: formKey,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE5E7EB))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('تفاصيل الرحلة: ${selType?['name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          TextField(controller: name, decoration: inDec('الاسم الكامل')),
          const SizedBox(height: 10),
          TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: inDec('رقم الهاتف للتواصل')),
          const SizedBox(height: 10),
          locBtn(true),
          const SizedBox(height: 10),
          locBtn(false),
          const SizedBox(height: 10),
          TextField(controller: note, decoration: inDec('ملاحظات (مثال: قرب الجامع / معلم معروف)')),
          if (sel == 'shared') ...[
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(color: const Color(0xFFF9FAFB), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE5E7EB))),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('عدد المقاعد المطلوب:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                DropdownButton<int>(value: seats, underline: const SizedBox(), items: [for (var i = 1; i <= 4; i++) DropdownMenuItem(value: i, child: Text('$i'))], onChanged: (v) => setState(() => seats = v ?? 1)),
              ]),
            ),
          ],
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel)),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text.rich(TextSpan(children: [const TextSpan(text: 'الأجرة التقديرية: ', style: TextStyle(fontWeight: FontWeight.w900)), TextSpan(text: kmText, style: const TextStyle(fontSize: 11, color: Colors.black54))])),
              Text(fareText, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ]),
          ),
          const SizedBox(height: 12),
          AppBtn(sending ? 'جاري إرسال الطلب...' : 'اطلب التكسي الآن', sending ? null : request, vPad: 14),
        ]),
      );

  Widget homePage() => ListView(controller: scroll, padding: EdgeInsets.fromLTRB(16, 16, 16, ride != null && !trackerHidden ? 210 : 24), children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.navy, C.dark, C.navy]), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x4DFFC107))),
          child: const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('اختر نوع رحلتك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: C.yel)),
              Text('محلي، أقضية، محافظات وخاص', style: TextStyle(fontSize: 12, color: Color(0xFFD1D5DB))),
            ]),
            Icon(Icons.local_taxi, size: 34, color: C.yel),
          ]),
        ),
        const SizedBox(height: 16),
        typesGrid(),
        if (sel != null) ...[const SizedBox(height: 16), form()],
      ]);

  Widget offersPage() => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('العروض', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 12),
        if (offers.isEmpty)
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE5E7EB))),
            child: const Column(children: [Icon(Icons.card_giftcard, size: 44, color: C.yel), SizedBox(height: 8), Text('لا توجد عروض حالياً', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black45)), Text('تابعنا قريباً', style: TextStyle(fontSize: 12, color: Colors.black38))]),
          )
        else
          for (final o in offers)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.navy, C.dark]), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0x66FFC107))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (o['badge'] != null) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(6)), child: Text(o['badge']!, style: const TextStyle(color: C.navy, fontSize: 10, fontWeight: FontWeight.w900))),
                Text(o['title'] ?? '', style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900)),
                Text(o['desc'] ?? '', style: const TextStyle(color: Color(0xFFD1D5DB), fontSize: 12)),
              ]),
            ),
      ]);

  Widget settingTile(Color bg, Color fg, IconData ic, String t, Widget sub, VoidCallback f) => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          onTap: () { click(); f(); },
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE5E7EB))),
            child: Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Icon(ic, color: fg)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontWeight: FontWeight.bold)), sub])),
              const Icon(Icons.chevron_left, size: 18, color: Colors.black38),
            ]),
          ),
        ),
      );

  Widget settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
        const Text('الإعدادات', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
        const SizedBox(height: 12),
        settingTile(const Color(0xFF16A34A), Colors.white, Icons.chat, 'الدعم الفني', const Text('تواصل معنا عبر واتساب', style: TextStyle(fontSize: 12, color: Colors.black54)), () => openUrl('https://wa.me/9647807750432')),
        settingTile(C.navy, C.yel, Icons.phone, 'رقم الهاتف', const Text('0780 775 0432', textDirection: TextDirection.ltr, style: TextStyle(fontSize: 12, color: Colors.black54)), () => openUrl('tel:+9647807750432')),
        settingTile(const Color(0xFFFBBF24), C.navy, Icons.notifications, 'فحص الإشعارات والموقع', const Text('اختبار صلاحيات التنبيه وتحديد الموقع', style: TextStyle(fontSize: 12, color: Colors.black54)), () => permCheck(context)),
        const SizedBox(height: 16),
        Center(child: Text(widget.user.email ?? '', textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 11, color: Colors.black38))),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج', style: TextStyle(fontSize: 12, color: Colors.black45, decoration: TextDecoration.underline))),
          TextButton(onPressed: () => openUrl(privacyUrl), child: const Text('الخصوصية', style: TextStyle(fontSize: 12, color: Colors.black45, decoration: TextDecoration.underline))),
          TextButton(onPressed: delAcc, child: const Text('حذف حسابي', style: TextStyle(fontSize: 12, color: Colors.black45, decoration: TextDecoration.underline))),
        ]),
      ]);

  Widget tracker() {
    final o = ride!;
    final s = steps[o['status']] ?? ('${o['status']}', .5);
    final hasDrv = o['driver_name'] != null && !endStatuses.contains(o['status']);
    return Positioned(
      left: 16, right: 16, bottom: 8,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: C.navy, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.yel, width: 2), boxShadow: const [BoxShadow(color: Color(0x66000000), blurRadius: 16)]),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('متابعة الرحلة مباشرة', style: TextStyle(fontSize: 10, color: C.yel, fontWeight: FontWeight.bold)),
            Flexible(child: Text(s.$1, style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w800))),
          ]),
          if (hasDrv)
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: C.dark, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0x4DFFC107))),
              child: Row(children: [
                const Icon(Icons.badge, size: 16, color: C.yel), const SizedBox(width: 6),
                Text('السائق: ${o['driver_name']} · ', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                GestureDetector(onTap: () => openUrl('tel:${o['driver_phone']}'), child: Text('${o['driver_phone'] ?? ''}', textDirection: TextDirection.ltr, style: const TextStyle(color: C.yel, fontSize: 12, fontWeight: FontWeight.bold, decoration: TextDecoration.underline))),
              ]),
            ),
          const SizedBox(height: 12),
          ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: s.$2, minHeight: 10, backgroundColor: C.dark, color: C.yel)),
          if (o['status'] == 'جديد') ...[const SizedBox(height: 12), AppBtn('إلغاء الرحلة', cancelRide, kind: BK.red, vPad: 8)],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [homePage(), offersPage(), settingsPage()];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          appHeader('تكسي بيجي', 'رحلات آمنة وسريعة'),
          Expanded(child: Stack(children: [
            Positioned.fill(child: IndexedStack(index: tab, children: pages)),
            if (ride != null && !trackerHidden) tracker(),
          ])),
        ]),
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(color: C.navy, border: Border(top: BorderSide(color: C.yel, width: 4))),
          child: SafeArea(
            top: false,
            child: Row(children: [
              for (final (i, ic, t) in [(0, Icons.local_taxi, 'الرئيسية'), (1, Icons.sell, 'العروض'), (2, Icons.settings, 'الإعدادات')])
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () { click(); setState(() => tab = i); },
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(color: tab == i ? const Color(0x24FFC107) : null, borderRadius: BorderRadius.circular(16)),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(ic, size: 22, color: tab == i ? C.yel : const Color(0xFF9CA3AF)),
                        Text(t, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: tab == i ? C.yel : const Color(0xFF9CA3AF))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// ============ شاشة اختيار الموقع على الخريطة ============
class MapPickerPage extends StatefulWidget {
  final bool pickup;
  final LatLng? initial;
  const MapPickerPage({super.key, required this.pickup, this.initial});
  @override
  State<MapPickerPage> createState() => _MapPickerPageState();
}

class _MapPickerPageState extends State<MapPickerPage> {
  static const c0 = LatLng(34.9311, 43.4883);
  final mc = MapController();
  bool lift = false;
  LatLng? me;
  late final LatLng start = widget.initial ?? c0;

  @override
  void initState() {
    super.initState();
    if (widget.pickup && widget.initial == null) WidgetsBinding.instance.addPostFrameCallback((_) => gps());
  }

  Future<void> gps() async {
    if (!await locOk()) {
      if (!mounted) return;
      showLocDisclosure(context, 'يستخدم التطبيق موقعك الدقيق أثناء استخدامك له فقط لتحديد نقطة الانطلاق على الخريطة، ويُرسل مع طلبك إلى الإدارة والسائق الذي يستلم رحلتك.\n\nلا نجمع الموقع والتطبيق مغلق.', gps);
      return;
    }
    try {
      final p = await getPos();
      final ll = LatLng(p.latitude, p.longitude);
      setState(() => me = ll);
      mc.move(ll, 17);
    } catch (e) { toast(locMsg(e)); }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.pickup ? const Color(0xFF16A34A) : const Color(0xFFDC2626);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Column(children: [
          Expanded(
            child: Stack(children: [
              FlutterMap(
                mapController: mc,
                options: MapOptions(
                  initialCenter: start,
                  initialZoom: widget.initial == null ? 14 : 16,
                  onMapEvent: (e) {
                    if (e is MapEventMoveStart && !lift) setState(() => lift = true);
                    if ((e is MapEventMoveEnd || e is MapEventFlingAnimationEnd) && lift) setState(() => lift = false);
                  },
                ),
                children: [
                  TileLayer(urlTemplate: mapTiles, userAgentPackageName: 'com.baiji.customer'),
                  if (me != null) MarkerLayer(markers: [Marker(point: me!, width: 18, height: 18, child: meDot())]),
                ],
              ),
              // ظل الدبوس + الدبوس في منتصف الخريطة
              IgnorePointer(
                child: Stack(children: [
                  Center(child: Container(width: 16, height: 6, decoration: BoxDecoration(color: const Color(0x4D000000), borderRadius: BorderRadius.circular(8)))),
                  Center(
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      transform: Matrix4.translationValues(0, lift ? -43 : -29, 0),
                      child: Icon(Icons.location_on, size: 58, color: color, shadows: const [Shadow(color: Color(0x59000000), blurRadius: 4, offset: Offset(0, 4))]),
                    ),
                  ),
                ]),
              ),
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    roundMapBtn(Icons.arrow_forward, () => Navigator.pop(context)),
                    const SizedBox(width: 8),
                    Expanded(child: mapChip(widget.pickup ? 'حدد نقطة الانطلاق' : 'حدد الوجهة')),
                  ]),
                ),
              ),
              Positioned(left: 12, bottom: 14, child: roundMapBtn(Icons.my_location, gps)),
            ]),
          ),
          mapSheet(Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('حرّك الخريطة حتى يستقر الدبوس على المكان بالضبط', style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: AppBtn('تأكيد الموقع', () => Navigator.pop(context, mc.camera.center), kind: BK.yellow, icon: Icons.check_circle, vPad: 14)),
          ])),
        ]),
      ),
    );
  }
}
