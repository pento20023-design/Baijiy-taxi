import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:latlong2/latlong.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

const supabaseUrl = 'https://xvrfcqhnzrkjzmqvxanl.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh2cmZjcWhuenJranptcXZ4YW5sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE1MzIzMzIsImV4cCI6MjEwNzEwODMzMn0.iiuuAVfo4jtCFxAIRrO6W9HhGUJjskSIbCAG_Cjpasw';
const privacyUrl = 'https://pento20026-ops.github.io/privacy.html';
const mapTiles = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const endStatuses = ['مكتملة', 'مرفوضة', 'ملغاة', 'لم يحضر'];

SupabaseClient get sb => Supabase.instance.client;

class C {
  static const navy = Color(0xFF0B1F4B);
  static const dark = Color(0xFF07142F);
  static const yel = Color(0xFFFFC107);
  static const yeld = Color(0xFFE0A800);
  static const soft = Color(0xFFFFF8E1);
  static const bg = Color(0xFFF5F7FB);
}

final messengerKey = GlobalKey<ScaffoldMessengerState>();

void toast(String t) {
  messengerKey.currentState
    ?..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(t, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
      backgroundColor: C.navy,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(milliseconds: 3500),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: C.yel)),
    ));
}

void click() => SystemSound.play(SystemSoundType.click);

Future<void> openUrl(String u) async {
  try {
    await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {
    toast('تعذر فتح الرابط');
  }
}

Future<bool> confirmDlg(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لا')),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('نعم')),
      ],
    ),
  );
  return r == true;
}

ThemeData buildTheme() => ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: C.navy, primary: C.navy, secondary: C.yel),
      scaffoldBackgroundColor: C.bg,
      textTheme: GoogleFonts.tajawalTextTheme(),
    );

/// زر بتدرّج لوني مثل أزرار النسخة الأصلية
enum BK { yellow, navy, white, red, green, sky, gray }

class AppBtn extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final BK kind;
  final IconData? icon;
  final double vPad;
  const AppBtn(this.text, this.onTap, {super.key, this.kind = BK.navy, this.icon, this.vPad = 13});

  @override
  Widget build(BuildContext context) {
    late List<Color> g;
    late Color fg;
    Border? border;
    switch (kind) {
      case BK.yellow:
        g = [const Color(0xFFFFD54F), const Color(0xFFFFB300)]; fg = C.navy; break;
      case BK.navy:
        g = [const Color(0xFF14327A), C.navy]; fg = C.yel; border = Border.all(color: const Color(0x73FFC107)); break;
      case BK.white:
        g = [Colors.white, Colors.white]; fg = C.navy; border = Border.all(color: const Color(0x330B1F4B)); break;
      case BK.red:
        g = [const Color(0xFFEF4444), const Color(0xFFDC2626)]; fg = Colors.white; break;
      case BK.green:
        g = [const Color(0xFF22C55E), const Color(0xFF15803D)]; fg = Colors.white; break;
      case BK.sky:
        g = [const Color(0xFF38BDF8), const Color(0xFF0284C7)]; fg = Colors.white; break;
      case BK.gray:
        g = [const Color(0xFFD1D5DB), const Color(0xFFD1D5DB)]; fg = const Color(0xFF374151); break;
    }
    final on = onTap != null;
    return Opacity(
      opacity: on ? 1 : .55,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: on ? () { click(); onTap!(); } : null,
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: g, begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(16),
              border: border,
              boxShadow: const [BoxShadow(color: Color(0x240B1F4B), blurRadius: 8, offset: Offset(0, 2))],
            ),
            padding: EdgeInsets.symmetric(vertical: vPad, horizontal: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[Icon(icon, size: 16, color: fg), const SizedBox(width: 6)],
                Flexible(child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 14))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

InputDecoration inDec(String hint) => InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.white,
      isDense: true,
      contentPadding: const EdgeInsets.all(12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFCBD5E1))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.navy, width: 2)),
    );

Widget appHeader(String title, String sub) => Container(
      decoration: const BoxDecoration(color: C.navy, border: Border(bottom: BorderSide(color: C.yel, width: 4))),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(children: [
            Container(
              width: 44, height: 44,
              decoration: BoxDecoration(color: C.yel, borderRadius: BorderRadius.circular(12), border: Border.all(color: C.yel, width: 2)),
              child: const Icon(Icons.local_taxi, color: C.navy),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(color: C.yel, fontWeight: FontWeight.w900, fontSize: 18, height: 1)),
              Text(sub, style: const TextStyle(color: Color(0xFFD1D5DB), fontSize: 10)),
            ]),
          ]),
        ),
      ),
    );

/// ===== الإشعارات =====
class Notifier {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static const _ch = AndroidNotificationChannel('rides', 'طلبات الرحلات',
      description: 'تنبيهات الطلبات وحالة الرحلة', importance: Importance.max);

  static Future<void> init() async {
    try {
      await _p.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
      await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(_ch);
      _ready = true;
    } catch (_) {}
  }

  static Future<bool> ask() async {
    try {
      final r = await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
      return r ?? true;
    } catch (_) { return false; }
  }

  static Future<void> show(String t, String b) async {
    if (!_ready) return;
    try {
      HapticFeedback.vibrate();
      await _p.show(
        DateTime.now().millisecondsSinceEpoch % 2147483000, t, b,
        NotificationDetails(android: AndroidNotificationDetails(_ch.id, _ch.name,
            channelDescription: _ch.description, importance: Importance.max, priority: Priority.high)),
      );
    } catch (e) { toast('تعذر عرض الإشعار: $e'); }
  }
}

/// ===== الموقع =====
Future<bool> locOk() async => (await SharedPreferences.getInstance()).getString('locOK') == '1';
Future<void> setLocOk() async => (await SharedPreferences.getInstance()).setString('locOK', '1');

String locMsg(Object e) {
  final m = e.toString().toLowerCase();
  if (RegExp('denied|permission').hasMatch(m)) return 'إذن الموقع مرفوض: فعّله للتطبيق من إعدادات الهاتف';
  if (RegExp('disabled|services|enabled|unavailable').hasMatch(m)) return 'خدمة الموقع (GPS) مغلقة: شغّلها من الإعدادات السريعة ثم أعد المحاولة';
  return 'تعذر تحديد الموقع، تأكد من تشغيل GPS وإذن الموقع';
}

Future<bool> ensureLocPermission() async {
  if (!await Geolocator.isLocationServiceEnabled()) throw 'disabled';
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) throw 'permission denied';
  return true;
}

Future<Position> getPos() async {
  await ensureLocPermission();
  return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
}

Future<void> showLocDisclosure(BuildContext c, String body, VoidCallback onYes) {
  return showDialog(
    context: c,
    builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: const BorderSide(color: C.yel, width: 2)),
      title: const Column(children: [Icon(Icons.my_location, size: 40, color: C.navy), SizedBox(height: 8), Text('استخدام الموقع', style: TextStyle(fontWeight: FontWeight.w900))]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(body, style: const TextStyle(fontSize: 13, height: 1.6)),
        const SizedBox(height: 8),
        GestureDetector(onTap: () => openUrl(privacyUrl), child: const Text('سياسة الخصوصية', style: TextStyle(decoration: TextDecoration.underline, fontSize: 11))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('ليس الآن')),
        TextButton(onPressed: () async { await setLocOk(); if (c.mounted) Navigator.pop(c); onYes(); }, child: const Text('موافق', style: TextStyle(fontWeight: FontWeight.w900))),
      ],
    ),
  );
}

/// فحص الصلاحيات (مقابل permCheck)
Future<void> permCheck(BuildContext c) async {
  final L = <String>[];
  try {
    final ok = await Notifier.ask();
    L.add('إذن الإشعارات: ${ok ? "مفعّل" : "مرفوض"}');
    if (ok) { await Notifier.show('🔔 تجربة الإشعارات', 'إذا ظهر هذا الإشعار فالتنبيهات تعمل'); L.add('أُرسل إشعار تجريبي — هل ظهر؟'); }
  } catch (e) { L.add('خطأ الإشعارات: $e'); }
  try {
    var p = await Geolocator.checkPermission();
    L.add('إذن الموقع: ${p.name}');
    if (p == LocationPermission.denied) { p = await Geolocator.requestPermission(); L.add('بعد الطلب: ${p.name}'); }
    L.add('خدمة GPS: ${await Geolocator.isLocationServiceEnabled() ? "تعمل" : "مغلقة"}');
  } catch (e) { L.add('خطأ الموقع: $e'); }
  if (!c.mounted) return;
  showDialog(context: c, builder: (_) => AlertDialog(content: Text(L.join('\n')), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('حسناً'))]));
}

/// أنماط الخريطة
String arErr(Object? m) {
  final s = (m is AuthException ? m.message : m).toString();
  if (RegExp('Invalid login', caseSensitive: false).hasMatch(s)) return 'البريد الإلكتروني أو كلمة السر غير صحيحة';
  if (RegExp('not confirmed', caseSensitive: false).hasMatch(s)) return 'يرجى تأكيد بريدك من الرسالة المرسلة إليك أولاً';
  if (RegExp('already registered|already been registered', caseSensitive: false).hasMatch(s)) return 'هذا البريد مسجّل مسبقاً، سجّل الدخول';
  if (RegExp('at least 6|weak', caseSensitive: false).hasMatch(s)) return 'كلمة السر ضعيفة (6 أحرف على الأقل)';
  if (RegExp('valid email|invalid format', caseSensitive: false).hasMatch(s)) return 'البريد الإلكتروني غير صالح';
  if (RegExp('rate limit|too many', caseSensitive: false).hasMatch(s)) return 'محاولات كثيرة، انتظر قليلاً ثم أعد المحاولة';
  if (RegExp('fetch|network|socket', caseSensitive: false).hasMatch(s)) return 'لا يوجد اتصال بالإنترنت';
  return s;
}

Widget meDot() => Container(
      width: 18, height: 18,
      decoration: BoxDecoration(color: const Color(0xFF1A73E8), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Color(0x801A73E8), blurRadius: 8)]),
    );

Widget pinIcon(Color color, {String? label}) => Column(mainAxisSize: MainAxisSize.min, children: [
      if (label != null)
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
          decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99)),
          child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
        ),
      Icon(Icons.location_on, color: color, size: 44, shadows: const [Shadow(color: Color(0x59000000), blurRadius: 4, offset: Offset(0, 3))]),
    ]);

Widget roundMapBtn(IconData i, VoidCallback f) => Material(
      color: Colors.white, shape: const CircleBorder(), elevation: 4,
      child: InkWell(customBorder: const CircleBorder(), onTap: () { click(); f(); }, child: SizedBox(width: 44, height: 44, child: Icon(i, color: C.navy, size: 18))),
    );

Widget mapChip(String t) => Material(
      color: Colors.white, elevation: 4, borderRadius: BorderRadius.circular(99),
      child: Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: C.navy, fontWeight: FontWeight.w800, fontSize: 13))),
    );

Widget mapSheet(Widget child) => Container(
      width: double.infinity,
      decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24)), boxShadow: [BoxShadow(color: Color(0x29000000), blurRadius: 24)]),
      padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + 0),
      child: SafeArea(top: false, child: child),
    );

double distKm(LatLng a, LatLng b) {
  double r(double x) => x * pi / 180;
  final h = pow(sin(r(b.latitude - a.latitude) / 2), 2) + cos(r(a.latitude)) * cos(r(b.latitude)) * pow(sin(r(b.longitude - a.longitude) / 2), 2);
  return (12742 * asin(sqrt(h)) * 1.25 * 10).round() / 10;
}
